import json
import asyncio
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import threading

class AIEcommerceHandler(BaseHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        from api.routes import APIRouter
        self.api_router = APIRouter()
        super().__init__(*args, **kwargs)
    
    def _set_headers(self, content_type='application/json'):
        self.send_response(200)
        self.send_header('Content-type', content_type)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.end_headers()

    def do_OPTIONS(self):
        self._set_headers()

    def do_GET(self):
        try:
            self._set_headers()
            parsed_path = urlparse(self.path)
            query_params = parse_qs(parsed_path.query)
            # Convert single item lists to single values
            clean_params = {k: v[0] if len(v) == 1 else v for k, v in query_params.items()}
            
            response = self.api_router.handle_get(parsed_path.path, clean_params)
            self.wfile.write(json.dumps(response).encode('utf-8'))
        except Exception as e:
            self._send_error_response(str(e))

    def do_POST(self):
        try:
            self._set_headers()
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length).decode('utf-8') if content_length > 0 else '{}'
            
            try:
                data = json.loads(post_data) if post_data else {}
            except json.JSONDecodeError:
                data = {}
            
            parsed_path = urlparse(self.path)
            response = self.api_router.handle_post(parsed_path.path, data)
            self.wfile.write(json.dumps(response).encode('utf-8'))
        except Exception as e:
            self._send_error_response(str(e))

    def do_PUT(self):
        try:
            self._set_headers()
            content_length = int(self.headers.get('Content-Length', 0))
            put_data = self.rfile.read(content_length).decode('utf-8') if content_length > 0 else '{}'
            
            try:
                data = json.loads(put_data) if put_data else {}
            except json.JSONDecodeError:
                data = {}
            
            parsed_path = urlparse(self.path)
            response = self.api_router.handle_put(parsed_path.path, data)
            self.wfile.write(json.dumps(response).encode('utf-8'))
        except Exception as e:
            self._send_error_response(str(e))

    def do_DELETE(self):
        try:
            self._set_headers()
            parsed_path = urlparse(self.path)
            response = self.api_router.handle_delete(parsed_path.path)
            self.wfile.write(json.dumps(response).encode('utf-8'))
        except Exception as e:
            self._send_error_response(str(e))

    def _send_error_response(self, error_message):
        self.send_response(500)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        error_response = {
            'status': 'error',
            'message': f'Internal server error: {error_message}'
        }
        self.wfile.write(json.dumps(error_response).encode('utf-8'))

def run_server():
    server_address = ('', 8000)
    httpd = HTTPServer(server_address, AIEcommerceHandler)
    print("🚀 AI E-commerce Server running on http://localhost:8000")
    print("📚 Available endpoints:")
    print("  GET  /api/products - Get all products")
    print("  POST /api/products/search - Semantic product search")
    print("  GET  /api/products/{id} - Get product details")
    print("  POST /api/chat - AI chatbot interaction")
    print("  POST /api/cart/add - Add to cart with NLP")
    print("  GET  /api/recommendations/{user_id} - Get AI recommendations")
    print("  POST /api/voice/process - Process voice input")
    print("  GET  /api/categories - Get product categories")
    print("  GET  /api/trending - Get trending products")
    
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n🛑 Shutting down server...")
        httpd.shutdown()

if __name__ == '__main__':
    run_server()