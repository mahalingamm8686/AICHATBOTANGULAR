import json
from typing import Any, List, Dict

class APIRouter:
    """API Router for handling all e-commerce endpoints with AI integration"""
    
    def __init__(self):
        # Initialize AI modules
        from ai_modules.nlp_processor import NLPProcessor
        from ai_modules.chatbot import AIChatbot
        
        self.nlp_processor = NLPProcessor()
        self.chatbot = AIChatbot()
        
        # Initialize database
        from database.db_manager import DatabaseManager
        self.db = DatabaseManager()
        
        # Initialize sample data
        self._initialize_sample_data()
    
    def _initialize_sample_data(self):
        """Initialize sample data for demonstration"""
        print("📦 Initializing sample data...")
        
        # Sample products data
        self.sample_products = [
            {"id": 1, "name": "iPhone 15 Pro", "description": "Latest smartphone with advanced camera and A17 Pro chip", "category": "Electronics", "brand": "Apple", "price": 999.99, "rating": 4.8, "stock_quantity": 50},
            {"id": 2, "name": "MacBook Air M2", "description": "Lightweight laptop with M2 chip for professionals", "category": "Electronics", "brand": "Apple", "price": 1299.99, "rating": 4.7, "stock_quantity": 30},
            {"id": 3, "name": "Nike Air Max 270", "description": "Comfortable running shoes with Air Max technology", "category": "Sports", "brand": "Nike", "price": 150.00, "rating": 4.5, "stock_quantity": 100},
            {"id": 4, "name": "Samsung Galaxy S24", "description": "Android smartphone with AI-powered camera", "category": "Electronics", "brand": "Samsung", "price": 899.99, "rating": 4.6, "stock_quantity": 75},
            {"id": 5, "name": "Sony WH-1000XM5", "description": "Premium noise-canceling headphones", "category": "Electronics", "brand": "Sony", "price": 349.99, "rating": 4.9, "stock_quantity": 25},
            {"id": 6, "name": "Apple Watch Series 9", "description": "Advanced smartwatch with health monitoring", "category": "Electronics", "brand": "Apple", "price": 399.99, "rating": 4.7, "stock_quantity": 40},
            {"id": 7, "name": "Adidas Ultraboost", "description": "Running shoes with responsive cushioning", "category": "Sports", "brand": "Adidas", "price": 180.00, "rating": 4.4, "stock_quantity": 80},
            {"id": 8, "name": "iPad Air", "description": "Versatile tablet for work and creativity", "category": "Electronics", "brand": "Apple", "price": 599.99, "rating": 4.6, "stock_quantity": 35}
        ]
        
        print("✅ Sample data initialized")

    def handle_get(self, path: str, params: Dict) -> Dict[str, Any]:
        """Handle GET requests"""
        try:
            if path == '/api/products' or path == '/api/products/':
                return self._get_products(params)
            elif path.startswith('/api/products/'):
                product_id = path.split('/')[-1]
                if product_id.isdigit():
                    return self._get_product_details(int(product_id))
                else:
                    return {'error': 'Invalid product ID', 'status': 400}
            elif path.startswith('/api/recommendations/'):
                user_id = path.split('/')[-1]
                return self._get_recommendations(user_id, params)
            elif path == '/api/categories' or path == '/api/categories/':
                return self._get_categories()
            elif path == '/api/trending' or path == '/api/trending/':
                return self._get_trending_products(params)
            elif path == '/api/search/analytics' or path == '/api/search/analytics/':
                return self._get_search_analytics()
            else:
                return {'error': 'Endpoint not found', 'status': 404}
        except Exception as e:
            return {'error': f'Server error: {str(e)}', 'status': 500}
    
    def handle_post(self, path: str, data: Dict) -> Dict[str, Any]:
        """Handle POST requests"""
        try:
            if path == '/api/products/search' or path == '/api/products/search/':
                return self._search_products(data)
            elif path == '/api/chat' or path == '/api/chat/':
                return self._chat_with_ai(data)
            elif path == '/api/cart/add' or path == '/api/cart/add/':
                return self._add_to_cart_nlp(data)
            elif path == '/api/voice/process' or path == '/api/voice/process/':
                return self._process_voice_input(data)
            elif path == '/api/orders' or path == '/api/orders/':
                return self._create_order(data)
            elif path == '/api/products/compare' or path == '/api/products/compare/':
                return self._compare_products(data)
            elif path == '/api/recommendations/update' or path == '/api/recommendations/update/':
                return self._update_recommendations(data)
            else:
                return {'error': 'Endpoint not found', 'status': 404}
        except Exception as e:
            return {'error': f'Server error: {str(e)}', 'status': 500}
    
    def handle_put(self, path: str, data: Dict) -> Dict[str, Any]:
        """Handle PUT requests"""
        try:
            if path.startswith('/api/products/'):
                product_id = path.split('/')[-1]
                if product_id.isdigit():
                    return self._update_product(int(product_id), data)
                else:
                    return {'error': 'Invalid product ID', 'status': 400}
            elif path.startswith('/api/users/'):
                user_id = path.split('/')[-1]
                return self._update_user_preferences(user_id, data)
            else:
                return {'error': 'Endpoint not found', 'status': 404}
        except Exception as e:
            return {'error': f'Server error: {str(e)}', 'status': 500}
    
    def handle_delete(self, path: str) -> Dict[str, Any]:
        """Handle DELETE requests"""
        try:
            if path.startswith('/api/products/'):
                product_id = path.split('/')[-1]
                if product_id.isdigit():
                    return self._delete_product(int(product_id))
                else:
                    return {'error': 'Invalid product ID', 'status': 400}
            else:
                return {'error': 'Endpoint not found', 'status': 404}
        except Exception as e:
            return {'error': f'Server error: {str(e)}', 'status': 500}
    
    def _get_products(self, params: Dict) -> Dict[str, Any]:
        """Get products with optional filtering"""
        try:
            limit = int(params.get('limit', 20))
            offset = int(params.get('offset', 0))
            category = params.get('category')
            
            # Filter products
            filtered_products = self.sample_products
            
            if category:
                filtered_products = [p for p in filtered_products if p['category'].lower() == category.lower()]
            
            # Apply pagination
            paginated_products = filtered_products[offset:offset + limit]
            
            return {
                'status': 'success',
                'data': paginated_products,
                'pagination': {
                    'limit': limit,
                    'offset': offset,
                    'total': len(filtered_products),
                    'has_more': (offset + limit) < len(filtered_products)
                }
            }
        except Exception as e:
            return {'error': str(e), 'status': 500}
    
    def _get_product_details(self, product_id: int) -> Dict[str, Any]:
        """Get detailed product information"""
        try:
            product = next((p for p in self.sample_products if p['id'] == product_id), None)
            
            if not product:
                return {'error': 'Product not found', 'status': 404}
            
            # Get AI-generated summary
            ai_summary = self._generate_product_summary(product)
            
            # Get similar products
            similar_products = self._get_similar_products(product_id, 4)
            
            return {
                'status': 'success',
                'data': {
                    'product': product,
                    'ai_summary': ai_summary,
                    'similar_products': similar_products,
                    'ai_recommendations': self._get_product_ai_recommendations(product)
                }
            }
        except Exception as e:
            return {'error': str(e), 'status': 500}
    
    def _search_products(self, data: Dict) -> Dict[str, Any]:
        """Semantic product search using AI"""
        try:
            query = data.get('query', '')
            search_type = data.get('type', 'semantic')
            filters = data.get('filters', {})
            limit = data.get('limit', 20)
            
            if not query:
                return {'error': 'Search query is required', 'status': 400}
            
            # Process query with NLP
            nlp_result = self.nlp_processor.process_user_query(query)
            
            # Perform search based on query
            search_results = self._perform_product_search(query, limit, filters)
            
            # Get AI insights about the search
            ai_insights = self._generate_search_insights(query, nlp_result, search_results)
            
            return {
                'status': 'success',
                'data': {
                    'query': query,
                    'nlp_analysis': nlp_result,
                    'results': search_results,
                    'ai_insights': ai_insights,
                    'total_results': len(search_results)
                }
            }
        except Exception as e:
            return {'error': str(e), 'status': 500}
    
    def _chat_with_ai(self, data: Dict) -> Dict[str, Any]:
        """Handle AI chatbot conversations"""
        try:
            user_id = data.get('user_id', 'anonymous')
            message = data.get('message', '')
            context = data.get('context', {})
            
            if not message:
                return {'error': 'Message is required', 'status': 400}
            
            # Process message with AI chatbot
            response = self.chatbot.process_message(user_id, message, context)
            
            return {
                'status': 'success',
                'data': response
            }
        except Exception as e:
            return {'error': str(e), 'status': 500}
    
    def _get_recommendations(self, user_id: str, params: Dict) -> Dict[str, Any]:
        """Get AI-powered recommendations for user"""
        try:
            recommendation_type = params.get('type', 'hybrid')
            limit = int(params.get('limit', 10))
            
            # Get recommendations based on user history and preferences
            recommendations = self._generate_recommendations(user_id, limit, recommendation_type)
            
            return {
                'status': 'success',
                'data': {
                    'recommendations': recommendations,
                    'recommendation_type': recommendation_type,
                    'user_id': user_id
                }
            }
        except Exception as e:
            return {'error': str(e), 'status': 500}
    
    def _add_to_cart_nlp(self, data: Dict) -> Dict[str, Any]:
        """Add to cart using natural language processing"""
        try:
            user_id = data.get('user_id')
            nlp_request = data.get('message', '')
            context = data.get('context', {})
            
            if not nlp_request:
                return {'error': 'Message is required', 'status': 400}
            
            # Process the natural language request
            nlp_result = self.nlp_processor.process_user_query(nlp_request)
            
            # Extract products and quantities
            products = nlp_result['entities'].get('products', [])
            quantities = nlp_result['entities'].get('quantities', [1])
            
            if not products:
                return {'error': 'No products identified in request', 'status': 400}
            
            # Find matching products
            cart_items = []
            for i, product_name in enumerate(products):
                # Search for product
                search_results = self._perform_product_search(product_name, 1, {})
                if search_results:
                    quantity = int(quantities[i] if i < len(quantities) else quantities[0])
                    product = search_results[0]
                    cart_items.append({
                        'product_id': product['id'],
                        'product_name': product['name'],
                        'quantity': quantity,
                        'price': product['price'],
                        'total_price': product['price'] * quantity
                    })
            
            return {
                'status': 'success',
                'data': {
                    'nlp_analysis': nlp_result,
                    'cart_items': cart_items,
                    'total_items': len(cart_items),
                    'total_price': sum(item['total_price'] for item in cart_items),
                    'message': f"Added {len(cart_items)} item(s) to your cart"
                }
            }
        except Exception as e:
            return {'error': str(e), 'status': 500}
    
    def _process_voice_input(self, data: Dict) -> Dict[str, Any]:
        """Process voice input for speech recognition"""
        try:
            # Mock voice processing
            audio_data = data.get('audio_data')
            user_id = data.get('user_id', 'anonymous')
            
            # Simulate speech-to-text conversion
            mock_transcriptions = [
                "Find me some running shoes",
                "Add iPhone to my cart",
                "Show me laptops under $1000",
                "What are the trending products today?",
                "Compare iPhone and Samsung Galaxy"
            ]
            
            import random
            transcribed_text = random.choice(mock_transcriptions)
            
            # Process transcribed text with chatbot
            response = self.chatbot.process_message(user_id, transcribed_text, {'source': 'voice'})
            
            return {
                'status': 'success',
                'data': {
                    'transcribed_text': transcribed_text,
                    'confidence': 0.95,
                    'ai_response': response
                }
            }
        except Exception as e:
            return {'error': str(e), 'status': 500}
    
    def _compare_products(self, data: Dict) -> Dict[str, Any]:
        """Compare products using AI analysis"""
        try:
            product_ids = data.get('product_ids', [])
            
            if len(product_ids) < 2:
                return {'error': 'At least 2 products required for comparison', 'status': 400}
            
            # Get product details
            products = []
            for product_id in product_ids:
                product = next((p for p in self.sample_products if p['id'] == product_id), None)
                if product:
                    products.append(product)
            
            if len(products) < 2:
                return {'error': 'Could not find enough products to compare', 'status': 404}
            
            # Generate AI-powered comparison
            comparison_analysis = self._generate_product_comparison(products)
            
            return {
                'status': 'success',
                'data': {
                    'products': products,
                    'comparison': comparison_analysis,
                    'recommendation': self._get_comparison_recommendation(products)
                }
            }
        except Exception as e:
            return {'error': str(e), 'status': 500}
    
    def _get_categories(self) -> Dict[str, Any]:
        """Get product categories"""
        categories = list(set(product['category'] for product in self.sample_products))
        category_data = []
        
        for i, category in enumerate(categories, 1):
            category_products = [p for p in self.sample_products if p['category'] == category]
            category_data.append({
                'id': i,
                'name': category,
                'description': f'{category} products and accessories',
                'product_count': len(category_products),
                'avg_rating': sum(p['rating'] for p in category_products) / len(category_products)
            })
        
        return {
            'status': 'success',
            'data': category_data
        }
    
    def _get_trending_products(self, params: Dict) -> Dict[str, Any]:
        """Get trending products"""
        try:
            days = int(params.get('days', 7))
            limit = int(params.get('limit', 10))
            
            # Simulate trending products (in real app, this would be based on actual data)
            trending_products = sorted(
                self.sample_products, 
                key=lambda x: (x['rating'], x['price']), 
                reverse=True
            )[:limit]
            
            # Add AI insights about trends
            trend_insights = self._analyze_trends(trending_products)
            
            return {
                'status': 'success',
                'data': {
                    'trending_products': trending_products,
                    'trend_analysis': trend_insights,
                    'time_period': f'{days} days'
                }
            }
        except Exception as e:
            return {'error': str(e), 'status': 500}
    
    def _create_order(self, data: Dict) -> Dict[str, Any]:
        """Create order with AI assistance"""
        try:
            user_id = data.get('user_id')
            items = data.get('items', [])
            shipping_address = data.get('shipping_address', '')
            
            if not user_id:
                return {'error': 'User ID is required', 'status': 400}
            if not items:
                return {'error': 'Order items are required', 'status': 400}
            
            # Calculate order total
            total_amount = sum(item.get('price', 0) * item.get('quantity', 1) for item in items)
            
            # Generate order ID
            import random
            order_id = random.randint(1000, 9999)
            
            # Generate AI-powered order summary and suggestions
            order_insights = self._generate_order_insights(order_id, items)
            
            return {
                'status': 'success',
                'data': {
                    'order_id': order_id,
                    'user_id': user_id,
                    'total_amount': total_amount,
                    'items': items,
                    'shipping_address': shipping_address,
                    'ai_insights': order_insights,
                    'estimated_delivery': '2-3 business days',
                    'tracking_available': True
                }
            }
        except Exception as e:
            return {'error': str(e), 'status': 500}
    
    # Helper methods
    
    def _perform_product_search(self, query: str, limit: int, filters: Dict) -> List[Dict]:
        """Perform product search based on query"""
        query_lower = query.lower()
        results = []
        
        for product in self.sample_products:
            # Check if product matches search query
            if (query_lower in product['name'].lower() or 
                query_lower in product['description'].lower() or
                query_lower in product['brand'].lower() or
                query_lower in product['category'].lower()):
                
                # Apply filters
                matches_filters = True
                if 'min_price' in filters and product['price'] < filters['min_price']:
                    matches_filters = False
                if 'max_price' in filters and product['price'] > filters['max_price']:
                    matches_filters = False
                if 'category' in filters and product['category'].lower() != filters['category'].lower():
                    matches_filters = False
                if 'brand' in filters and product['brand'].lower() != filters['brand'].lower():
                    matches_filters = False
                
                if matches_filters:
                    results.append(product)
        
        # Sort by relevance (simplified)
        results.sort(key=lambda x: x['rating'], reverse=True)
        return results[:limit]
    
    def _get_similar_products(self, product_id: int, limit: int) -> List[Dict]:
        """Get similar products based on category and price range"""
        original_product = next((p for p in self.sample_products if p['id'] == product_id), None)
        if not original_product:
            return []
        
        similar = []
        for product in self.sample_products:
            if product['id'] != product_id:
                # Calculate similarity score
                score = 0
                if product['category'] == original_product['category']:
                    score += 2
                if product['brand'] == original_product['brand']:
                    score += 1
                if abs(product['price'] - original_product['price']) < 200:
                    score += 1
                
                if score > 0:
                    similar.append((product, score))
        
        # Sort by similarity score and get top results
        similar.sort(key=lambda x: x[1], reverse=True)
        return [product for product, score in similar[:limit]]
    
    def _generate_recommendations(self, user_id: str, limit: int, rec_type: str) -> List[Dict]:
        """Generate product recommendations"""
        # Simple recommendation logic - in production, use ML models
        if rec_type == 'popular':
            return sorted(self.sample_products, key=lambda x: x['rating'], reverse=True)[:limit]
        else:
            # Hybrid approach - mix of popular and diverse categories
            popular = sorted(self.sample_products, key=lambda x: x['rating'], reverse=True)
            diverse = []
            categories_covered = set()
            
            for product in popular:
                if product['category'] not in categories_covered:
                    diverse.append(product)
                    categories_covered.add(product['category'])
            
            # Combine and limit
            combined = popular[:limit//2] + diverse[:limit//2]
            return combined[:limit]
    
    def _generate_product_summary(self, product: Dict) -> str:
        """Generate AI summary of product"""
        name = product.get('name', 'Product')
        description = product.get('description', '')
        rating = product.get('rating', 0)
        price = product.get('price', 0)
        
        summary = f"The {name} is a highly-rated product"
        
        if rating >= 4.5:
            summary += " with excellent customer reviews"
        elif rating >= 4.0:
            summary += " with very good customer feedback"
        
        if price <= 100:
            summary += " offering great value for money"
        elif price <= 500:
            summary += " in the mid-range price category"
        else:
            summary += " positioned as a premium product"
        
        summary += f". {description[:100]}..." if description else "."
        
        return summary
    
    def _generate_search_insights(self, query: str, nlp_result: Dict, search_results: List) -> Dict:
        """Generate AI insights about search results"""
        intent = nlp_result.get('intent', 'general')
        entities = nlp_result.get('entities', {})
        
        insights = {
            'search_intent': intent,
            'extracted_entities': entities,
            'result_count': len(search_results),
            'suggestions': []
        }
        
        # Generate contextual suggestions
        if intent == 'search':
            insights['suggestions'].extend([
                'Filter by price range',
                'Sort by customer ratings',
                'Show similar products'
            ])
        elif intent == 'comparison':
            insights['suggestions'].extend([
                'View detailed comparison',
                'Check price history',
                'Read customer reviews'
            ])
        
        return insights
    
    def _generate_product_comparison(self, products: List[Dict]) -> Dict:
        """Generate AI-powered product comparison"""
        comparison = {
            'summary': f"Comparing {len(products)} products across key features",
            'features': {},
            'recommendations': []
        }
        
        # Compare prices
        prices = [float(p.get('price', 0)) for p in products]
        price_analysis = {
            'lowest': min(prices),
            'highest': max(prices),
            'difference': max(prices) - min(prices)
        }
        comparison['features']['price'] = price_analysis
        
        # Compare ratings
        ratings = [float(p.get('rating', 0)) for p in products]
        rating_analysis = {
            'highest_rated': max(ratings),
            'lowest_rated': min(ratings),
            'average': sum(ratings) / len(ratings)
        }
        comparison['features']['ratings'] = rating_analysis
        
        return comparison
    
    def _get_comparison_recommendation(self, products: List[Dict]) -> str:
        """Get AI recommendation from product comparison"""
        if not products:
            return "No products to compare"
        
        # Simple logic for demonstration
        best_rating = max(products, key=lambda p: float(p.get('rating', 0)))
        best_value = min(products, key=lambda p: float(p.get('price', 999999)))
        
        if best_rating == best_value:
            return f"I recommend {best_rating['name']} as it offers the best combination of quality and value"
        else:
            return f"For quality, choose {best_rating['name']}. For budget, {best_value['name']} is your best option"
    
    def _get_product_ai_recommendations(self, product: Dict) -> List[str]:
        """Get AI recommendations for a specific product"""
        recommendations = []
        
        rating = float(product.get('rating', 0))
        price = float(product.get('price', 0))
        
        if rating >= 4.5:
            recommendations.append("Highly recommended by customers")
        
        if price <= 100:
            recommendations.append("Great value for money")
        elif price >= 500:
            recommendations.append("Premium quality investment")
        
        recommendations.append("Consider adding complementary accessories")
        
        return recommendations
    
    def _analyze_trends(self, trending_products: List[Dict]) -> Dict:
        """Analyze trends in popular products"""
        if not trending_products:
            return {'insight': 'No trending data available'}
        
        # Analyze categories
        categories = [p.get('category', 'Unknown') for p in trending_products]
        category_counts = {}
        for cat in categories:
            category_counts[cat] = category_counts.get(cat, 0) + 1
        
        top_category = max(category_counts, key=category_counts.get)
        
        return {
            'insight': f'{top_category} products are trending',
            'category_distribution': category_counts,
            'total_trending': len(trending_products)
        }
    
    def _generate_order_insights(self, order_id: int, items: List[Dict]) -> Dict:
        """Generate AI insights for order"""
        total_items = sum(item.get('quantity', 0) for item in items)
        total_value = sum(item.get('price', 0) * item.get('quantity', 0) for item in items)
        
        insights = {
            'order_summary': f'Order contains {total_items} items worth ${total_value:.2f}',
            'suggestions': [
                'Consider purchasing product protection',
                'Sign up for delivery notifications',
                'Rate your purchase after delivery'
            ]
        }
        
        # Add personalized suggestions based on order
        if total_value > 500:
            insights['suggestions'].append('You qualify for premium customer support')
        
        return insights
    
    def _get_search_analytics(self) -> Dict[str, Any]:
        """Get search analytics"""
        return {
            'status': 'success',
            'data': {
                'total_searches': 1500,
                'popular_queries': ['iphone', 'laptop', 'headphones'],
                'conversion_rate': '15.2%'
            }
        }
    
    def _update_product(self, product_id: int, data: Dict) -> Dict[str, Any]:
        """Update product"""
        product = next((p for p in self.sample_products if p['id'] == product_id), None)
        if not product:
            return {'error': 'Product not found', 'status': 404}
        
        # Update product data
        for key, value in data.items():
            if key in product:
                product[key] = value
        
        return {
            'status': 'success',
            'data': {
                'product_id': product_id,
                'message': 'Product updated successfully'
            }
        }
    
    def _update_user_preferences(self, user_id: str, data: Dict) -> Dict[str, Any]:
        """Update user preferences"""
        return {
            'status': 'success',
            'data': {
                'user_id': user_id,
                'message': 'Preferences updated successfully'
            }
        }
    
    def _delete_product(self, product_id: int) -> Dict[str, Any]:
        """Delete product"""
        global_sample_products = [p for p in self.sample_products if p['id'] != product_id]
        if len(global_sample_products) == len(self.sample_products):
            return {'error': 'Product not found', 'status': 404}
        
        self.sample_products = global_sample_products
        return {
            'status': 'success',
            'data': {
                'product_id': product_id,
                'message': 'Product deleted successfully'
            }
        }
    
    def _update_recommendations(self, data: Dict) -> Dict[str, Any]:
        """Update recommendations based on user action"""
        user_id = data.get('user_id')
        product_id = data.get('product_id')
        action = data.get('action')
        
        return {
            'status': 'success',
            'data': {
                'message': 'Recommendations updated'
            }
        }