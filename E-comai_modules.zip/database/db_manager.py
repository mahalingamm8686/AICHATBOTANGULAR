import mysql.connector
import json
from typing import List, Dict, Any, Optional


class DatabaseManager:
    def __init__(self):
        """Connect to local MySQL database"""
        try:
            print("🔗 Connecting to MySQL...")
            self.conn = mysql.connector.connect(
                host="127.0.0.1",      # Localhost
                port=3306,             # Default MySQL port
                user="root",           # Your username
                password="Test@123",  # Your MySQL password
                database="db_ecommerce"    # Your database name
            )
            self.cursor = self.conn.cursor(dictionary=True)
            print("✅ Connected to MySQL")
        except mysql.connector.Error as e:
            print(f"❌ Database connection failed: {e}")
            raise

    def get_products(self, limit=20, offset=0, category_id=None) -> List[Dict[str, Any]]:
        """Get list of products with optional category filter"""
        try:
            if category_id:
                query = "SELECT * FROM products WHERE category_id = %s LIMIT %s OFFSET %s"
                self.cursor.execute(query, (category_id, limit, offset))
            else:
                query = "SELECT * FROM products LIMIT %s OFFSET %s"
                self.cursor.execute(query, (limit, offset))
            return self.cursor.fetchall()
        except mysql.connector.Error as e:
            print(f"❌ Error getting products: {e}")
            return []

    def get_product(self, product_id: int) -> Dict[str, Any]:
        """Get single product by ID"""
        try:
            query = "SELECT * FROM products WHERE id = %s"
            self.cursor.execute(query, (product_id,))
            return self.cursor.fetchone()
        except mysql.connector.Error as e:
            print(f"❌ Error getting product: {e}")
            return {}

    def sp_save_chat_session(self, user_id: int, session_data: Dict) -> int:
        """Save AI chat session data"""
        try:
            session_json = json.dumps(session_data)
            
            # Check if session exists for user
            query = "SELECT id FROM chat_sessions WHERE user_id = %s"
            self.cursor.execute(query, (user_id,))
            existing = self.cursor.fetchone()
            
            if existing:
                # Update existing session
                query = """
                    UPDATE chat_sessions 
                    SET session_data = %s, updated_at = CURRENT_TIMESTAMP
                    WHERE user_id = %s
                """
                self.cursor.execute(query, (session_json, user_id))
                session_id = existing['id']
            else:
                # Create new session
                query = """
                    INSERT INTO chat_sessions (user_id, session_data)
                    VALUES (%s, %s)
                """
                self.cursor.execute(query, (user_id, session_json))
                session_id = self.cursor.lastrowid
            
            self.conn.commit()
            return session_id
        except Exception as e:
            print(f"❌ Error saving chat session: {e}")
            self.conn.rollback()
            return 0

    def sp_update_user_interaction(self, user_id: int, product_id: int, interaction_type: str, interaction_data: str = None) -> bool:
        """Record user interaction for AI learning"""
        try:
            query = """
                INSERT INTO user_interactions (user_id, product_id, interaction_type, interaction_data)
                VALUES (%s, %s, %s, %s)
            """
            self.cursor.execute(query, (user_id, product_id, interaction_type, interaction_data))
            self.conn.commit()
            return True
        except Exception as e:
            print(f"❌ Error recording interaction: {e}")
            self.conn.rollback()
            return False

    def sp_search_products_semantic(self, query: str, limit: int = 20) -> List[Dict]:
        """Semantic product search"""
        try:
            search_pattern = f'%{query}%'
            search_query = """
                SELECT p.*, c.name as category_name
                FROM products p
                JOIN categories c ON p.category_id = c.id
                WHERE (p.name LIKE %s OR p.description LIKE %s OR p.brand LIKE %s)
                   AND p.stock_quantity > 0
                ORDER BY p.rating DESC, p.review_count DESC
                LIMIT %s
            """
            self.cursor.execute(search_query, (search_pattern, search_pattern, search_pattern, limit))
            return self.cursor.fetchall()
        except Exception as e:
            print(f"❌ Error in semantic search: {e}")
            return []

    def sp_get_product_recommendations(self, user_id: int, limit: int = 10) -> List[Dict]:
        """Get personalized product recommendations"""
        try:
            # Simple implementation - in production, use more complex logic
            query = """
                SELECT p.*, c.name as category_name,
                       (p.rating * p.review_count) as popularity_score
                FROM products p
                JOIN categories c ON p.category_id = c.id
                WHERE p.stock_quantity > 0
                ORDER BY popularity_score DESC, p.rating DESC
                LIMIT %s
            """
            self.cursor.execute(query, (limit,))
            return self.cursor.fetchall()
        except Exception as e:
            print(f"❌ Error getting recommendations: {e}")
            return []

    def sp_get_trending_products(self, days: int = 7, limit: int = 10) -> List[Dict]:
        """Get trending products based on recent interactions"""
        try:
            query = """
                SELECT p.*, c.name as category_name,
                       COUNT(ui.id) as recent_interactions
                FROM products p
                JOIN categories c ON p.category_id = c.id
                LEFT JOIN user_interactions ui ON p.id = ui.product_id
                    AND ui.timestamp > DATE_SUB(NOW(), INTERVAL %s DAY)
                WHERE p.stock_quantity > 0
                GROUP BY p.id
                ORDER BY recent_interactions DESC, p.rating DESC
                LIMIT %s
            """
            self.cursor.execute(query, (days, limit))
            return self.cursor.fetchall()
        except Exception as e:
            print(f"❌ Error getting trending products: {e}")
            return []

    def create_order(self, user_id: int, items: List[Dict], shipping_address: str) -> int:
        """Create new order"""
        try:
            # Calculate total
            total_amount = sum(item['price'] * item['quantity'] for item in items)
            
            # Create order
            query = """
                INSERT INTO orders (user_id, total_amount, shipping_address)
                VALUES (%s, %s, %s)
            """
            self.cursor.execute(query, (user_id, total_amount, shipping_address))
            order_id = self.cursor.lastrowid
            
            # Add order items
            for item in items:
                query = """
                    INSERT INTO order_items (order_id, product_id, quantity, price)
                    VALUES (%s, %s, %s, %s)
                """
                self.cursor.execute(query, (order_id, item['product_id'], item['quantity'], item['price']))
            
            self.conn.commit()
            return order_id
            
        except Exception as e:
            self.conn.rollback()
            print(f"❌ Error creating order: {e}")
            return 0

    def close(self):
        """Close the database connection"""
        if self.cursor:
            self.cursor.close()
        if self.conn:
            self.conn.close()
            print("🔒 MySQL connection closed")






# import json
# import sqlite3
# from typing import List, Dict, Any, Optional
# from datetime import datetime
# import os

# class DatabaseManager:
    
#     def __init__(self, db_path: str = "db_ecommerce"):
#         self.db_path = db_path
#         self.connection = None
#         self._initialize_database()
        
    
#     def _initialize_database(self):
#         """Initialize database with e-commerce schema"""
#         self.connection = sqlite3.connect(self.db_path, check_same_thread=False)
#         self.connection.row_factory = sqlite3.Row
        
#         # Create tables
#         self._create_tables()
#         self._create_stored_procedures()
#         self._insert_sample_data()
    
#     def _create_tables(self):
#         """Create e-commerce database tables"""
#         cursor = self.connection.cursor()
        
#         # Users table
#         cursor.execute('''
#             CREATE TABLE IF NOT EXISTS users (
#                 id INTEGER PRIMARY KEY AUTOINCREMENT,
#                 email TEXT UNIQUE NOT NULL,
#                 name TEXT NOT NULL,
#                 password_hash TEXT NOT NULL,
#                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
#                 preferences TEXT,
#                 ai_profile TEXT
#             )
#         ''')
        
#         # Categories table
#         cursor.execute('''
#             CREATE TABLE IF NOT EXISTS categories (
#                 id INTEGER PRIMARY KEY AUTOINCREMENT,
#                 name TEXT NOT NULL,
#                 description TEXT,
#                 parent_id INTEGER,
#                 FOREIGN KEY (parent_id) REFERENCES categories(id)
#             )
#         ''')
        
#         # Products table
#         cursor.execute('''
#             CREATE TABLE IF NOT EXISTS products (
#                 id INTEGER PRIMARY KEY AUTOINCREMENT,
#                 name TEXT NOT NULL,
#                 description TEXT,
#                 price DECIMAL(10, 2) NOT NULL,
#                 category_id INTEGER,
#                 brand TEXT,
#                 sku TEXT UNIQUE,
#                 stock_quantity INTEGER DEFAULT 0,
#                 rating DECIMAL(3, 2) DEFAULT 0.0,
#                 review_count INTEGER DEFAULT 0,
#                 features TEXT,
#                 images TEXT,
#                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
#                 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
#                 FOREIGN KEY (category_id) REFERENCES categories(id)
#             )
#         ''')
        
#         # Orders table
#         cursor.execute('''
#             CREATE TABLE IF NOT EXISTS orders (
#                 id INTEGER PRIMARY KEY AUTOINCREMENT,
#                 user_id INTEGER NOT NULL,
#                 total_amount DECIMAL(10, 2) NOT NULL,
#                 status TEXT DEFAULT 'pending',
#                 shipping_address TEXT,
#                 payment_status TEXT DEFAULT 'pending',
#                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
#                 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
#                 FOREIGN KEY (user_id) REFERENCES users(id)
#             )
#         ''')
        
#         # Order items table
#         cursor.execute('''
#             CREATE TABLE IF NOT EXISTS order_items (
#                 id INTEGER PRIMARY KEY AUTOINCREMENT,
#                 order_id INTEGER NOT NULL,
#                 product_id INTEGER NOT NULL,
#                 quantity INTEGER NOT NULL,
#                 price DECIMAL(10, 2) NOT NULL,
#                 FOREIGN KEY (order_id) REFERENCES orders(id),
#                 FOREIGN KEY (product_id) REFERENCES products(id)
#             )
#         ''')
        
#         # Reviews table
#         cursor.execute('''
#             CREATE TABLE IF NOT EXISTS reviews (
#                 id INTEGER PRIMARY KEY AUTOINCREMENT,
#                 product_id INTEGER NOT NULL,
#                 user_id INTEGER NOT NULL,
#                 rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
#                 review_text TEXT,
#                 sentiment_score DECIMAL(3, 2),
#                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
#                 FOREIGN KEY (product_id) REFERENCES products(id),
#                 FOREIGN KEY (user_id) REFERENCES users(id)
#             )
#         ''')
        
#         # User interactions table (for ML/AI)
#         cursor.execute('''
#             CREATE TABLE IF NOT EXISTS user_interactions (
#                 id INTEGER PRIMARY KEY AUTOINCREMENT,
#                 user_id INTEGER NOT NULL,
#                 product_id INTEGER NOT NULL,
#                 interaction_type TEXT NOT NULL,
#                 interaction_data TEXT,
#                 timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
#                 FOREIGN KEY (user_id) REFERENCES users(id),
#                 FOREIGN KEY (product_id) REFERENCES products(id)
#             )
#         ''')
        
#         # AI chat sessions table
#         cursor.execute('''
#             CREATE TABLE IF NOT EXISTS chat_sessions (
#                 id INTEGER PRIMARY KEY AUTOINCREMENT,
#                 user_id INTEGER NOT NULL,
#                 session_data TEXT,
#                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
#                 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
#                 FOREIGN KEY (user_id) REFERENCES users(id)
#             )
#         ''')
        
#         self.connection.commit()
    
#     def _create_stored_procedures(self):
#         """Create stored procedure equivalents as Python methods"""
#         # Note: SQLite doesn't support stored procedures, so we implement them as methods
#         pass
    
#     def _insert_sample_data(self):
#         """Insert sample data for testing"""
#         cursor = self.connection.cursor()
        
#         # Check if data already exists
#         cursor.execute("SELECT COUNT(*) FROM categories")
#         if cursor.fetchone()[0] > 0:
#             return
        
#         # Insert categories
#         categories = [
#             ('Electronics', 'Electronic devices and gadgets', None),
#             ('Clothing', 'Fashion and apparel', None),
#             ('Books', 'Books and literature', None),
#             ('Home & Garden', 'Home and garden products', None),
#             ('Smartphones', 'Mobile phones and accessories', 1),
#             ('Laptops', 'Portable computers', 1),
#             ('Men\'s Clothing', 'Clothing for men', 2),
#             ('Women\'s Clothing', 'Clothing for women', 2)
#         ]
        
#         cursor.executemany(
#             "INSERT INTO categories (name, description, parent_id) VALUES (?, ?, ?)",
#             categories
#         )
        
#         # Insert sample products
#         products = [
#             ('iPhone 15 Pro', 'Latest iPhone with advanced features', 999.99, 5, 'Apple', 'IP15P-001', 50, 4.8, 1250, '["A17 Pro chip", "Titanium design", "48MP camera"]', '["iphone15_1.jpg", "iphone15_2.jpg"]'),
#             ('MacBook Air M2', 'Powerful and lightweight laptop', 1299.99, 6, 'Apple', 'MBA-M2-001', 30, 4.7, 890, '["M2 chip", "13-inch display", "18 hour battery"]', '["macbook_1.jpg", "macbook_2.jpg"]'),
#             ('Nike Air Max 270', 'Comfortable running shoes', 150.00, 7, 'Nike', 'NAM270-001', 100, 4.5, 2100, '["Air Max cushioning", "Breathable mesh", "Rubber outsole"]', '["nike270_1.jpg", "nike270_2.jpg"]'),
#             ('Samsung Galaxy S24', 'Android smartphone with AI features', 899.99, 5, 'Samsung', 'SGS24-001', 75, 4.6, 980, '["AI-powered camera", "120Hz display", "5000mAh battery"]', '["galaxy_1.jpg", "galaxy_2.jpg"]'),
#             ('Sony WH-1000XM5', 'Noise-canceling headphones', 349.99, 1, 'Sony', 'SONYWH-001', 25, 4.9, 1500, '["Industry-leading noise canceling", "30-hour battery", "Multipoint connection"]', '["sony_headphones_1.jpg"]')
#         ]
        
#         cursor.executemany(
#             "INSERT INTO products (name, description, price, category_id, brand, sku, stock_quantity, rating, review_count, features, images) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
#             products
#         )
        
#         # Insert sample users
#         users = [
#             ('john@example.com', 'John Doe', 'hashed_password_1', '{"preferred_categories": ["Electronics"], "price_range": "medium"}', '{"interaction_history": [], "preferences": {}}'),
#             ('jane@example.com', 'Jane Smith', 'hashed_password_2', '{"preferred_categories": ["Clothing", "Electronics"], "price_range": "high"}', '{"interaction_history": [], "preferences": {}}'),
#             ('mike@example.com', 'Mike Johnson', 'hashed_password_3', '{"preferred_categories": ["Books", "Home & Garden"], "price_range": "low"}', '{"interaction_history": [], "preferences": {}}')
#         ]
        
#         cursor.executemany(
#             "INSERT INTO users (email, name, password_hash, preferences, ai_profile) VALUES (?, ?, ?, ?, ?)",
#             users
#         )
        
#         self.connection.commit()
    
#     # Stored Procedure Equivalents
    
#     def sp_get_product_recommendations(self, user_id: int, limit: int = 10) -> List[Dict]:
#         """Stored procedure: Get personalized product recommendations"""
#         cursor = self.connection.cursor()
        
#         # Get user preferences
#         cursor.execute("SELECT preferences FROM users WHERE id = ?", (user_id,))
#         user_data = cursor.fetchone()
        
#         if not user_data:
#             return []
        
#         try:
#             preferences = json.loads(user_data['preferences']) if user_data['preferences'] else {}
#         except:
#             preferences = {}
        
#         # Get user's interaction history
#         cursor.execute('''
#             SELECT product_id, interaction_type, COUNT(*) as interaction_count
#             FROM user_interactions 
#             WHERE user_id = ? 
#             GROUP BY product_id, interaction_type
#         ''', (user_id,))
        
#         interactions = cursor.fetchall()
        
#         # Build recommendation query based on preferences and interactions
#         preferred_categories = preferences.get('preferred_categories', [])
        
#         if preferred_categories:
#             placeholders = ','.join(['?' for _ in preferred_categories])
#             query = f'''
#                 SELECT p.*, c.name as category_name,
#                        (p.rating * p.review_count) as popularity_score
#                 FROM products p
#                 JOIN categories c ON p.category_id = c.id
#                 WHERE c.name IN ({placeholders})
#                    AND p.stock_quantity > 0
#                 ORDER BY popularity_score DESC, p.rating DESC
#                 LIMIT ?
#             '''
#             cursor.execute(query, preferred_categories + [limit])
#         else:
#             # General recommendations based on popularity
#             cursor.execute('''
#                 SELECT p.*, c.name as category_name,
#                        (p.rating * p.review_count) as popularity_score
#                 FROM products p
#                 JOIN categories c ON p.category_id = c.id
#                 WHERE p.stock_quantity > 0
#                 ORDER BY popularity_score DESC, p.rating DESC
#                 LIMIT ?
#             ''', (limit,))
        
#         products = cursor.fetchall()
#         return [dict(product) for product in products]
    
#     def sp_search_products_semantic(self, search_query: str, limit: int = 20) -> List[Dict]:
#         """Stored procedure: Semantic product search"""
#         cursor = self.connection.cursor()
        
#         # Simple text search (in production, use full-text search or vector search)
#         query = '''
#             SELECT p.*, c.name as category_name
#             FROM products p
#             JOIN categories c ON p.category_id = c.id
#             WHERE (p.name LIKE ? OR p.description LIKE ? OR p.brand LIKE ?)
#                AND p.stock_quantity > 0
#             ORDER BY p.rating DESC, p.review_count DESC
#             LIMIT ?
#         '''
        
#         search_pattern = f'%{search_query}%'
#         cursor.execute(query, (search_pattern, search_pattern, search_pattern, limit))
        
#         products = cursor.fetchall()
#         return [dict(product) for product in products]
    
#     def sp_update_user_interaction(self, user_id: int, product_id: int, interaction_type: str, interaction_data: str = None) -> bool:
#         """Stored procedure: Record user interaction for AI learning"""
#         cursor = self.connection.cursor()
        
#         try:
#             cursor.execute('''
#                 INSERT INTO user_interactions (user_id, product_id, interaction_type, interaction_data)
#                 VALUES (?, ?, ?, ?)
#             ''', (user_id, product_id, interaction_type, interaction_data))
            
#             self.connection.commit()
#             return True
#         except Exception as e:
#             print(f"Error recording interaction: {e}")
#             return False
    
#     def sp_get_trending_products(self, days: int = 7, limit: int = 10) -> List[Dict]:
#         """Stored procedure: Get trending products based on recent interactions"""
#         cursor = self.connection.cursor()
        
#         query = '''
#             SELECT p.*, c.name as category_name,
#                    COUNT(ui.id) as recent_interactions,
#                    AVG(CASE WHEN ui.interaction_type = 'purchase' THEN 5
#                            WHEN ui.interaction_type = 'cart_add' THEN 3
#                            WHEN ui.interaction_type = 'view' THEN 1
#                            ELSE 0 END) as trend_score
#             FROM products p
#             JOIN categories c ON p.category_id = c.id
#             LEFT JOIN user_interactions ui ON p.id = ui.product_id
#                 AND ui.timestamp > datetime('now', '-{} days')
#             WHERE p.stock_quantity > 0
#             GROUP BY p.id
#             ORDER BY trend_score DESC, recent_interactions DESC, p.rating DESC
#             LIMIT ?
#         '''.format(days)
        
#         cursor.execute(query, (limit,))
        
#         products = cursor.fetchall()
#         return [dict(product) for product in products]
    
#     def sp_save_chat_session(self, user_id: int, session_data: Dict) -> int:
#         """Stored procedure: Save AI chat session data"""
#         cursor = self.connection.cursor()
        
#         try:
#             session_json = json.dumps(session_data)
            
#             # Check if session exists for user
#             cursor.execute("SELECT id FROM chat_sessions WHERE user_id = ?", (user_id,))
#             existing = cursor.fetchone()
            
#             if existing:
#                 # Update existing session
#                 cursor.execute('''
#                     UPDATE chat_sessions 
#                     SET session_data = ?, updated_at = CURRENT_TIMESTAMP
#                     WHERE user_id = ?
#                 ''', (session_json, user_id))
#                 session_id = existing['id']
#             else:
#                 # Create new session
#                 cursor.execute('''
#                     INSERT INTO chat_sessions (user_id, session_data)
#                     VALUES (?, ?)
#                 ''', (user_id, session_json))
#                 session_id = cursor.lastrowid
            
#             self.connection.commit()
#             return session_id
#         except Exception as e:
#             print(f"Error saving chat session: {e}")
#             return 0
    
#     def sp_get_user_purchase_history(self, user_id: int, limit: int = 50) -> List[Dict]:
#         """Stored procedure: Get user's purchase history for AI personalization"""
#         cursor = self.connection.cursor()
        
#         query = '''
#             SELECT o.id as order_id, o.total_amount, o.status, o.created_at as order_date,
#                    oi.quantity, oi.price as item_price,
#                    p.id as product_id, p.name as product_name, p.brand, p.category_id,
#                    c.name as category_name
#             FROM orders o
#             JOIN order_items oi ON o.id = oi.order_id
#             JOIN products p ON oi.product_id = p.id
#             JOIN categories c ON p.category_id = c.id
#             WHERE o.user_id = ?
#             ORDER BY o.created_at DESC
#             LIMIT ?
#         '''
        
#         cursor.execute(query, (user_id, limit))
        
#         purchases = cursor.fetchall()
#         return [dict(purchase) for purchase in purchases]
    
#     # Standard CRUD operations
    
#     def get_product(self, product_id: int) -> Optional[Dict]:
#         """Get product by ID"""
#         cursor = self.connection.cursor()
#         cursor.execute('''
#             SELECT p.*, c.name as category_name
#             FROM products p
#             JOIN categories c ON p.category_id = c.id
#             WHERE p.id = ?
#         ''', (product_id,))
        
#         product = cursor.fetchone()
#         return dict(product) if product else None
    
#     def get_products(self, limit: int = 50, offset: int = 0, category_id: int = None) -> List[Dict]:
#         """Get products with pagination and optional category filter"""
#         cursor = self.connection.cursor()
        
#         if category_id:
#             cursor.execute('''
#                 SELECT p.*, c.name as category_name
#                 FROM products p
#                 JOIN categories c ON p.category_id = c.id
#                 WHERE p.category_id = ?
#                 ORDER BY p.created_at DESC
#                 LIMIT ? OFFSET ?
#             ''', (category_id, limit, offset))
#         else:
#             cursor.execute('''
#                 SELECT p.*, c.name as category_name
#                 FROM products p
#                 JOIN categories c ON p.category_id = c.id
#                 ORDER BY p.created_at DESC
#                 LIMIT ? OFFSET ?
#             ''', (limit, offset))
        
#         products = cursor.fetchall()
#         return [dict(product) for product in products]
    
#     def create_order(self, user_id: int, items: List[Dict], shipping_address: str) -> int:
#         """Create new order"""
#         cursor = self.connection.cursor()
        
#         try:
#             # Calculate total
#             total_amount = sum(item['price'] * item['quantity'] for item in items)
            
#             # Create order
#             cursor.execute('''
#                 INSERT INTO orders (user_id, total_amount, shipping_address)
#                 VALUES (?, ?, ?)
#             ''', (user_id, total_amount, shipping_address))
            
#             order_id = cursor.lastrowid
            
#             # Add order items
#             for item in items:
#                 cursor.execute('''
#                     INSERT INTO order_items (order_id, product_id, quantity, price)
#                     VALUES (?, ?, ?, ?)
#                 ''', (order_id, item['product_id'], item['quantity'], item['price']))
            
#             self.connection.commit()
#             return order_id
            
#         except Exception as e:
#             self.connection.rollback()
#             print(f"Error creating order: {e}")
#             return 0
    
#     def get_user_orders(self, user_id: int) -> List[Dict]:
#         """Get all orders for a user"""
#         cursor = self.connection.cursor()
#         cursor.execute('''
#             SELECT * FROM orders 
#             WHERE user_id = ? 
#             ORDER BY created_at DESC
#         ''', (user_id,))
        
#         orders = cursor.fetchall()
#         return [dict(order) for order in orders]
    
#     def close_connection(self):
#         """Close database connection"""
#         if self.connection:
#             self.connection.close()