import json
from datetime import datetime
from typing import Dict, List, Any
from .nlp_processor import NLPProcessor

class AIChatbot:
    def __init__(self):
        self.nlp_processor = NLPProcessor()
        self.conversation_memory = {}
        self.user_sessions = {}
        self.product_knowledge = {
            "iphone": {
                "name": "iPhone 15 Pro",
                "price": 999.99,
                "features": ["A17 Pro chip", "Titanium design", "48MP camera", "5G"],
                "category": "Electronics",
                "rating": 4.8
            },
            "macbook": {
                "name": "MacBook Air M2", 
                "price": 1299.99,
                "features": ["M2 chip", "13-inch display", "18 hour battery"],
                "category": "Electronics",
                "rating": 4.7
            },
            "nike": {
                "name": "Nike Air Max 270",
                "price": 150.00,
                "features": ["Air Max cushioning", "Breathable mesh", "Rubber outsole"],
                "category": "Sports",
                "rating": 4.5
            },
            "samsung": {
                "name": "Samsung Galaxy S24",
                "price": 899.99,
                "features": ["AI-powered camera", "120Hz display", "5000mAh battery"],
                "category": "Electronics", 
                "rating": 4.6
            },
            "sony": {
                "name": "Sony WH-1000XM5",
                "price": 349.99,
                "features": ["Noise canceling", "30-hour battery", "Multipoint connection"],
                "category": "Electronics",
                "rating": 4.9
            }
        }

    def process_message(self, user_id: str, message: str, context: Dict = None) -> Dict[str, Any]:
        """Process user message and generate response"""
        try:
            if user_id not in self.user_sessions:
                self.user_sessions[user_id] = {
                    "start_time": datetime.now().isoformat(),
                    "message_count": 0,
                    "last_intent": None,
                    "conversation_flow": []
                }

            session = self.user_sessions[user_id]
            session["message_count"] += 1

            # Process with NLP
            nlp_result = self.nlp_processor.process_user_query(message)
            
            # Generate response based on intent
            response = self._generate_response(user_id, nlp_result, context or {})
            
            # Update conversation memory
            self._update_conversation_memory(user_id, message, nlp_result, response)
            
            return {
                "status": "success",
                "data": response
            }
        except Exception as e:
            return {
                "status": "error",
                "data": {
                    "message": "I encountered an error. Please try again.",
                    "intent": "error"
                }
            }

    def _generate_response(self, user_id: str, nlp_result: Dict, context: Dict) -> Dict[str, Any]:
        """Generate response based on NLP analysis"""
        intent = nlp_result.get("intent", "general")
        entities = nlp_result.get("entities", {})
        
        # Handle different intents
        if intent == "search":
            return self._handle_search(entities)
        elif intent == "price_inquiry":
            return self._handle_price_inquiry(entities)
        elif intent == "product_details":
            return self._handle_product_details(entities)
        elif intent == "comparison":
            return self._handle_comparison(entities)
        elif intent == "recommendation":
            return self._handle_recommendation(user_id, entities)
        elif intent == "trending":
            return self._handle_trending()
        elif intent == "cart":
            return self._handle_cart(entities)
        elif intent == "help":
            return self._handle_help()
        else:
            return self._handle_general(entities)

    def _handle_search(self, entities: Dict) -> Dict[str, Any]:
        """Handle product search intent"""
        products = entities.get('products', [])
        brands = entities.get('brands', [])
        categories = entities.get('categories', [])
        
        if not products and not categories:
            return {
                "message": "I'd be happy to help you find products! What are you looking for? You can search for phones, laptops, headphones, shoes, etc.",
                "intent": "search",
                "suggestions": [
                    "Search for phones",
                    "Find laptops", 
                    "Look for headphones",
                    "Show me running shoes"
                ]
            }
        
        search_terms = products + categories
        primary_term = search_terms[0] if search_terms else "products"
        brand_filter = brands[0] if brands else "any brand"
        
        # Find matching products
        matching_products = []
        for product_key, product_info in self.product_knowledge.items():
            if (any(term in product_key for term in search_terms) or 
                any(term in product_info['category'].lower() for term in search_terms)):
                if not brands or product_info['name'].lower() in [b.lower() for b in brands]:
                    matching_products.append(product_info)
        
        if matching_products:
            product_names = [p['name'] for p in matching_products[:3]]
            message = f"I found {len(matching_products)} {primary_term} options from {brand_filter}. Top matches: {', '.join(product_names)}"
        else:
            message = f"I couldn't find exact matches for '{primary_term}', but here are some related products you might like."
            matching_products = list(self.product_knowledge.values())[:3]
        
        return {
            "message": message,
            "intent": "search",
            "actions": ["show_search_results"],
            "data": {
                "query": primary_term,
                "filters": {"brand": brand_filter},
                "results": matching_products,
                "results_count": len(matching_products)
            },
            "suggestions": [
                "Filter by price",
                "Sort by rating", 
                "Show more details",
                "Compare products"
            ]
        }

    def _handle_price_inquiry(self, entities: Dict) -> Dict[str, Any]:
        """Handle price inquiries"""
        products = entities.get('products', [])
        
        if not products:
            return {
                "message": "Which product would you like to know the price of? I can check prices for iPhones, MacBooks, Samsung phones, Nike shoes, Sony headphones, and more.",
                "intent": "price_inquiry",
                "suggestions": [
                    "iPhone price",
                    "MacBook cost", 
                    "Samsung Galaxy price",
                    "Nike shoes price"
                ]
            }
        
        product_key = products[0].lower()
        product_info = self.product_knowledge.get(product_key)
        
        if not product_info:
            # Try to find similar product
            for key, info in self.product_knowledge.items():
                if product_key in key or any(product_key in feature.lower() for feature in info['features']):
                    product_info = info
                    break
        
        if product_info:
            message = f"The {product_info['name']} costs ${product_info['price']:.2f}"
            if product_info.get('discount'):
                message += f" (originally ${product_info['original_price']:.2f}, {product_info['discount']}% off!)"
            
            message += f". It has a {product_info['rating']}/5 rating."
                
            return {
                "message": message,
                "intent": "price_inquiry",
                "data": product_info,
                "suggestions": [
                    "Compare prices",
                    "Check availability", 
                    "Add to cart",
                    "See similar products"
                ]
            }
        else:
            return {
                "message": f"I don't have pricing information for {products[0]}. Would you like me to search for similar products?",
                "intent": "price_inquiry",
                "suggestions": ["Search for similar", "Check other products", "Main menu"]
            }

    def _handle_product_details(self, entities: Dict) -> Dict[str, Any]:
        """Handle product detail requests"""
        products = entities.get('products', [])
        
        if not products:
            return {
                "message": "Which product would you like details about? I can show you features, specifications, and reviews for our products.",
                "intent": "product_details",
                "suggestions": [
                    "iPhone details",
                    "MacBook specifications", 
                    "Sony headphones features",
                    "Nike shoes information"
                ]
            }
        
        product_key = products[0].lower()
        product_info = self.product_knowledge.get(product_key)
        
        if not product_info:
            # Try to find similar
            for key, info in self.product_knowledge.items():
                if product_key in key:
                    product_info = info
                    break
        
        if product_info:
            features_str = ", ".join(product_info['features'])
            message = f"Here are the details for {product_info['name']}:\n"
            message += f"• Price: ${product_info['price']:.2f}\n"
            message += f"• Rating: {product_info['rating']}/5 stars\n" 
            message += f"• Category: {product_info['category']}\n"
            message += f"• Key Features: {features_str}"
            
            return {
                "message": message,
                "intent": "product_details",
                "data": product_info,
                "suggestions": ["Check price", "Compare with similar", "Add to cart", "Read reviews"]
            }
        else:
            return {
                "message": f"I don't have detailed information for {products[0]} yet. Would you like me to search for similar products?",
                "intent": "product_details",
                "suggestions": ["Search for similar", "Browse categories", "Ask about another product"]
            }

    def _handle_comparison(self, entities: Dict) -> Dict[str, Any]:
        """Handle product comparison requests"""
        products = entities.get('products', [])
        
        if len(products) < 2:
            return {
                "message": "Which two products would you like to compare? For example: 'Compare iPhone and Samsung' or 'MacBook vs iPad'",
                "intent": "comparison",
                "suggestions": [
                    "iPhone vs Samsung",
                    "MacBook vs iPad", 
                    "Nike vs Adidas",
                    "Sony headphones vs others"
                ]
            }
        
        product1_info = self.product_knowledge.get(products[0].lower())
        product2_info = self.product_knowledge.get(products[1].lower())
        
        if not product1_info or not product2_info:
            return {
                "message": f"I can compare {products[0]} and {products[1]}, but I need more information about one of them. Try asking about specific models.",
                "intent": "comparison"
            }
        
        # Simple comparison logic
        price_diff = product1_info['price'] - product2_info['price']
        rating_diff = product1_info['rating'] - product2_info['rating']
        
        if price_diff > 0:
            price_msg = f"{product1_info['name']} is ${abs(price_diff):.2f} more expensive"
        else:
            price_msg = f"{product2_info['name']} is ${abs(price_diff):.2f} more expensive"
        
        if rating_diff > 0:
            rating_msg = f"{product1_info['name']} has a higher rating"
        elif rating_diff < 0:
            rating_msg = f"{product2_info['name']} has a higher rating" 
        else:
            rating_msg = "Both have similar ratings"
        
        recommendation = f"Based on your needs, I'd recommend {product1_info['name'] if rating_diff >= 0 else product2_info['name']} for better value."
        
        message = f"Comparing {product1_info['name']} and {product2_info['name']}:\n"
        message += f"• {price_msg}\n"
        message += f"• {rating_msg}\n"
        message += f"• {recommendation}"
        
        return {
            "message": message,
            "intent": "comparison",
            "data": {
                "products": [product1_info, product2_info],
                "differences": {
                    "price_difference": abs(price_diff),
                    "rating_difference": abs(rating_diff)
                },
                "recommendation": recommendation
            },
            "suggestions": ["Show detailed specs", "Check prices", "See alternatives", "Add to comparison"]
        }

    def _handle_recommendation(self, user_id: str, entities: Dict) -> Dict[str, Any]:
        """Handle product recommendations"""
        categories = entities.get('categories', [])
        products = entities.get('products', [])
        
        if categories:
            # Recommend based on category
            category_recs = []
            for product_info in self.product_knowledge.values():
                if any(cat in product_info['category'].lower() for cat in categories):
                    category_recs.append(product_info)
            
            if category_recs:
                rec_products = category_recs[:3]
                category_name = categories[0].title()
                message = f"Based on your interest in {category_name}, I recommend:"
                for product in rec_products:
                    message += f"\n• {product['name']} - ${product['price']:.2f} ({product['rating']}/5)"
            else:
                rec_products = list(self.product_knowledge.values())[:3]
                message = "Here are some popular products you might like:"
                for product in rec_products:
                    message += f"\n• {product['name']} - ${product['price']:.2f}"
        else:
            # General recommendations
            rec_products = list(self.product_knowledge.values())[:3]
            message = "Based on popular choices, I recommend:"
            for product in rec_products:
                message += f"\n• {product['name']} - ${product['price']:.2f} ({product['rating']}/5)"
        
        return {
            "message": message,
            "intent": "recommendation",
            "data": {
                "recommendations": rec_products,
                "reason": "Popular and highly rated"
            },
            "suggestions": ["Show me phones", "Laptop options", "Audio devices", "Sports equipment"]
        }

    def _handle_trending(self) -> Dict[str, Any]:
        """Handle trending products request"""
        # Get top rated products as "trending"
        trending = sorted(self.product_knowledge.values(), 
                         key=lambda x: x['rating'], reverse=True)[:3]
        
        message = "Currently trending products:\n"
        for product in trending:
            message += f"• {product['name']} - ${product['price']:.2f} ({product['rating']}/5 rating)\n"
        message += "These are our most popular and highly-rated items!"
        
        return {
            "message": message,
            "intent": "trending",
            "data": {
                "trending_products": trending,
                "reason": "High customer ratings and popularity"
            },
            "suggestions": ["Show details", "Check prices", "Compare trending", "See all products"]
        }

    def _handle_cart(self, entities: Dict) -> Dict[str, Any]:
        """Handle cart-related requests"""
        products = entities.get('products', [])
        quantities = entities.get('quantities', [1])
        
        if not products:
            return {
                "message": "What would you like to add to your cart? Just tell me the product name and quantity.",
                "intent": "cart",
                "suggestions": [
                    "Add iPhone to cart",
                    "Buy MacBook", 
                    "Order Nike shoes",
                    "View my cart"
                ]
            }
        
        product_key = products[0].lower()
        quantity = quantities[0] if quantities else 1
        product_info = self.product_knowledge.get(product_key)
        
        if product_info:
            total_price = product_info['price'] * quantity
            message = f"I've added {quantity} {product_info['name']}(s) to your cart. Total: ${total_price:.2f}"
            
            return {
                "message": message,
                "intent": "cart",
                "actions": ["add_to_cart"],
                "data": {
                    "product": product_info,
                    "quantity": quantity,
                    "total_price": total_price
                },
                "suggestions": ["Continue shopping", "View cart", "Checkout", "Add another product"]
            }
        else:
            return {
                "message": f"I couldn't find '{products[0]}' in our catalog. Would you like me to search for similar products?",
                "intent": "cart",
                "suggestions": ["Search for similar", "Browse categories", "Check product names"]
            }

    def _handle_help(self) -> Dict[str, Any]:
        """Handle help requests"""
        message = "I'm your AI shopping assistant! Here's what I can help you with:\n"
        message += "• Search for products (phones, laptops, etc.)\n"
        message += "• Check prices and compare products\n" 
        message += "• Get product details and features\n"
        message += "• Get personalized recommendations\n"
        message += "• Add items to your cart\n"
        message += "• Check trending products\n\n"
        message += "Just tell me what you're looking for or ask for help!"
        
        return {
            "message": message,
            "intent": "help",
            "suggestions": [
                "Search for iPhone",
                "Show me laptops", 
                "What's trending?",
                "Recommend products"
            ]
        }

    def _handle_general(self, entities: Dict) -> Dict[str, Any]:
        """Handle general conversations"""
        products = entities.get('products', [])
        
        if products:
            # If products mentioned but no clear intent, offer help with them
            product = products[0]
            return {
                "message": f"I see you mentioned {product}. Would you like me to show you prices, details, or help you find similar products?",
                "intent": "general",
                "suggestions": [
                    f"Price of {product}",
                    f"Details about {product}",
                    f"Compare {product} with others",
                    "Show me recommendations"
                ]
            }
        else:
            return {
                "message": "Hello! I'm your AI shopping assistant. I can help you search for products, compare prices, check details, or recommend the best options. What would you like to do?",
                "intent": "general",
                "suggestions": [
                    "Help me find a product",
                    "What's on sale?", 
                    "Show me recommendations",
                    "Compare products"
                ]
            }

    def _update_conversation_memory(self, user_id: str, message: str, nlp_result: Dict, response: Dict):
        """Update conversation history"""
        if user_id not in self.conversation_memory:
            self.conversation_memory[user_id] = []
        
        self.conversation_memory[user_id].append({
            "timestamp": datetime.now().isoformat(),
            "user_message": message,
            "ai_response": response["message"],
            "intent": nlp_result["intent"],
            "entities": nlp_result["entities"]
        })
        
        # Keep only last 10 messages
        if len(self.conversation_memory[user_id]) > 10:
            self.conversation_memory[user_id] = self.conversation_memory[user_id][-10:]

    def get_conversation_summary(self, user_id: str) -> Dict[str, Any]:
        """Get summary of conversation with user"""
        if user_id not in self.conversation_memory:
            return {"message_count": 0, "last_intent": None}
        
        conversations = self.conversation_memory[user_id]
        intents = [conv["intent"] for conv in conversations]
        
        return {
            "message_count": len(conversations),
            "last_intent": intents[-1] if intents else None,
            "common_intents": max(set(intents), key=intents.count) if intents else None,
            "last_interaction": conversations[-1]["timestamp"] if conversations else None
        }