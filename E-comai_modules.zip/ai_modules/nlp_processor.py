import re
import json
from typing import Dict, List, Any

class NLPProcessor:
    def __init__(self):
        self.intent_keywords = {
            'search': ['search', 'find', 'look for', 'show me', 'looking for', 'want to buy'],
            'price_inquiry': ['price', 'cost', 'how much', 'expensive', 'cheap'],
            'product_details': ['details', 'specifications', 'features', 'about', 'information'],
            'comparison': ['compare', 'vs', 'versus', 'difference between', 'better'],
            'recommendation': ['recommend', 'suggest', 'what should I buy', 'advice'],
            'trending': ['trending', 'popular', 'best selling', 'hot', 'trends'],
            'cart': ['add to cart', 'cart', 'buy', 'purchase', 'order'],
            'help': ['help', 'support', 'assist', 'what can you do']
        }
        
        self.entity_patterns = {
            'products': r'\b(iphone|macbook|nike|samsung|sony|headphones|shoes|laptop|phone|watch|ipad|adidas|ultraboost)\b',
            'brands': r'\b(apple|samsung|nike|sony|adidas)\b',
            'colors': r'\b(red|blue|black|white|green|silver|gold)\b',
            'quantities': r'\b(one|two|three|four|five|\d+)\b',
            'categories': r'\b(electronics|sports|clothing|phones|laptops|headphones|shoes)\b'
        }

    def process_user_query(self, query: str) -> Dict[str, Any]:
        """Process user query and extract intent and entities"""
        query_lower = query.lower().strip()
        
        if not query_lower:
            return {
                'intent': 'general',
                'entities': {},
                'confidence': 0.0,
                'original_query': query
            }
        
        # Detect intent
        intent = self._detect_intent(query_lower)
        
        # Extract entities
        entities = self._extract_entities(query_lower)
        
        # Calculate confidence
        confidence = self._calculate_confidence(intent, entities, query_lower)
        
        return {
            'intent': intent,
            'entities': entities,
            'confidence': confidence,
            'original_query': query
        }

    def _detect_intent(self, query: str) -> str:
        """Detect user intent from query"""
        for intent, keywords in self.intent_keywords.items():
            for keyword in keywords:
                if keyword in query:
                    return intent
        return 'general'

    def _extract_entities(self, query: str) -> Dict[str, List[str]]:
        """Extract entities from query"""
        entities = {}
        
        for entity_type, pattern in self.entity_patterns.items():
            matches = re.findall(pattern, query, re.IGNORECASE)
            if matches:
                # Convert to list and remove duplicates
                entities[entity_type] = list(set(matches))
        
        return entities

    def _calculate_confidence(self, intent: str, entities: Dict, query: str) -> float:
        """Calculate confidence score for the analysis"""
        confidence = 0.5  # Base confidence
        
        # Increase confidence if we found entities
        if entities:
            confidence += 0.3
        
        # Increase confidence for specific intents with relevant entities
        if intent == 'search' and entities.get('products'):
            confidence += 0.1
        elif intent == 'price_inquiry' and entities.get('products'):
            confidence += 0.1
        elif intent == 'comparison' and len(entities.get('products', [])) >= 2:
            confidence += 0.1
        
        # Cap at 1.0
        return min(confidence, 1.0)

    def analyze_sentiment(self, text: str) -> Dict[str, Any]:
        """Simple sentiment analysis"""
        positive_words = ['good', 'great', 'excellent', 'amazing', 'love', 'nice', 'perfect', 'awesome', 'fantastic']
        negative_words = ['bad', 'terrible', 'awful', 'hate', 'poor', 'disappointing', 'horrible', 'worst']
        
        text_lower = text.lower()
        positive_count = sum(1 for word in positive_words if word in text_lower)
        negative_count = sum(1 for word in negative_words if word in text_lower)
        
        if positive_count > negative_count:
            sentiment = 'positive'
            score = min(0.9, 0.5 + (positive_count * 0.1))
        elif negative_count > positive_count:
            sentiment = 'negative'
            score = min(0.9, 0.5 + (negative_count * 0.1))
        else:
            sentiment = 'neutral'
            score = 0.5
            
        return {
            'sentiment': sentiment,
            'score': score,
            'positive_words': positive_count,
            'negative_words': negative_count
        }

    def extract_product_preferences(self, query: str) -> Dict[str, Any]:
        """Extract product preferences from user query"""
        preferences = {
            'price_range': None,
            'brands': [],
            'categories': [],
            'features': []
        }
        
        query_lower = query.lower()
        
        # Extract price range
        price_patterns = {
            'budget': r'(\$?(\d+)\s*-\s*\$?(\d+))',
            'under': r'under\s*\$?(\d+)',
            'less than': r'less than\s*\$?(\d+)',
            'over': r'over\s*\$?(\d+)',
            'more than': r'more than\s*\$?(\d+)'
        }
        
        for pattern_type, pattern in price_patterns.items():
            matches = re.findall(pattern, query_lower)
            if matches:
                if pattern_type == 'budget':
                    preferences['price_range'] = {
                        'min': float(matches[0][1]),
                        'max': float(matches[0][2])
                    }
                elif pattern_type in ['under', 'less than']:
                    preferences['price_range'] = {
                        'min': 0,
                        'max': float(matches[0])
                    }
                elif pattern_type in ['over', 'more than']:
                    preferences['price_range'] = {
                        'min': float(matches[0]),
                        'max': float('inf')
                    }
        
        return preferences