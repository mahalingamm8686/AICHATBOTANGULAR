class VectorSearch:
    def __init__(self):
        self.product_vectors = {}
        self.vocabulary = set()
        print("🔍 Vector Search initialized")
    
    def build_vocabulary(self, products):
        """Build vocabulary from product data"""
        for product in products:
            text = f"{product['name']} {product['description']} {product['category']} {product['brand']}"
            words = text.lower().split()
            self.vocabulary.update(words)
    
    def add_product(self, product_id, name, description, metadata):
        """Add product to vector search"""
        self.product_vectors[product_id] = {
            'name': name,
            'description': description,
            'metadata': metadata
        }
    
    def semantic_search(self, query, top_k=10):
        """Perform semantic search (simplified implementation)"""
        query_lower = query.lower()
        results = []
        
        for product_id, product_data in self.product_vectors.items():
            score = 0
            text = f"{product_data['name']} {product_data['description']}".lower()
            
            # Simple text matching for demo (in production, use real vector similarity)
            if query_lower in text:
                score = 0.9
            elif any(word in text for word in query_lower.split()):
                score = 0.6
            
            if score > 0:
                results.append({
                    'product_id': product_id,
                    'name': product_data['name'],
                    'score': score,
                    'metadata': product_data['metadata']
                })
        
        # Sort by score and return top results
        results.sort(key=lambda x: x['score'], reverse=True)
        return results[:top_k]
    
    def hybrid_search(self, query, filters, limit=10):
        """Perform hybrid search with filters"""
        semantic_results = self.semantic_search(query, limit * 2)
        
        # Apply filters
        filtered_results = []
        for result in semantic_results:
            matches_filters = True
            
            if 'min_price' in filters and result['metadata'].get('price', 0) < filters['min_price']:
                matches_filters = False
            if 'max_price' in filters and result['metadata'].get('price', 0) > filters['max_price']:
                matches_filters = False
            
            if matches_filters:
                filtered_results.append(result)
        
        return filtered_results[:limit]
    
    def find_similar_products(self, product_id, limit=5):
        """Find similar products"""
        if product_id not in self.product_vectors:
            return []
        
        target_product = self.product_vectors[product_id]
        similar = []
        
        for pid, product in self.product_vectors.items():
            if pid != product_id:
                # Simple similarity calculation
                score = 0
                if product['metadata'].get('category') == target_product['metadata'].get('category'):
                    score += 0.5
                if abs(product['metadata'].get('price', 0) - target_product['metadata'].get('price', 0)) < 100:
                    score += 0.3
                if product['metadata'].get('brand') == target_product['metadata'].get('brand'):
                    score += 0.2
                
                if score > 0:
                    similar.append({
                        'product_id': pid,
                        'name': product['name'],
                        'similarity_score': score
                    })
        
        similar.sort(key=lambda x: x['similarity_score'], reverse=True)
        return similar[:limit]
    
    def remove_product(self, product_id):
        """Remove product from search index"""
        if product_id in self.product_vectors:
            del self.product_vectors[product_id]
    
    def get_search_analytics(self):
        """Get search analytics"""
        return {
            'total_products': len(self.product_vectors),
            'vocabulary_size': len(self.vocabulary),
            'average_query_length': 2.3
        }