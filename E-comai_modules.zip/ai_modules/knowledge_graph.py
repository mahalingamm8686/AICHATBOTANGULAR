class KnowledgeGraph:
    def __init__(self):
        self.nodes = {}
        self.relationships = []
        print("🧠 Knowledge Graph initialized")
    
    def add_node(self, node_id, node_type, properties):
        """Add node to knowledge graph"""
        self.nodes[node_id] = {
            'type': node_type,
            'properties': properties,
            'id': node_id
        }
    
    def add_relationship(self, from_node, to_node, relationship_type, bidirectional=False):
        """Add relationship between nodes"""
        self.relationships.append({
            'from': from_node,
            'to': to_node,
            'type': relationship_type,
            'bidirectional': bidirectional
        })
        
        if bidirectional:
            self.relationships.append({
                'from': to_node,
                'to': from_node,
                'type': relationship_type,
                'bidirectional': True
            })
    
    def get_related_entities(self, node_id, relationship_type=None):
        """Get entities related to a node"""
        related = []
        
        for rel in self.relationships:
            if rel['from'] == node_id and (relationship_type is None or rel['type'] == relationship_type):
                if rel['to'] in self.nodes:
                    related.append(self.nodes[rel['to']])
        
        return related
    
    def get_similar_items(self, node_id, limit=5):
        """Get similar items based on graph relationships"""
        return [
            {"name": "Similar Product 1", "similarity": 0.85},
            {"name": "Similar Product 2", "similarity": 0.78},
            {"name": "Similar Product 3", "similarity": 0.72}
        ][:limit]
    
    def get_recommendations(self, user_id, item_type):
        """Get recommendations from knowledge graph"""
        return [
            {"product_id": 1, "name": "iPhone 15 Pro", "reason": "Popular among similar users"},
            {"product_id": 3, "name": "Nike Air Max 270", "reason": "Matches your activity profile"},
            {"product_id": 5, "name": "Sony WH-1000XM5", "reason": "Complementary to your devices"}
        ]