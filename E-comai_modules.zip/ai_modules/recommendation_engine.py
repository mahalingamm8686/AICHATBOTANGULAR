class RecommendationEngine:
    def __init__(self):
        self.user_interactions = {}
        print("🎯 Recommendation Engine initialized")
    
    def collaborative_filtering_recommendations(self, user_id, limit=10):
        """Generate recommendations using collaborative filtering"""
        return [
            {"product_id": 1, "name": "iPhone 15 Pro", "score": 0.95},
            {"product_id": 2, "name": "MacBook Air M2", "score": 0.88},
            {"product_id": 4, "name": "Samsung Galaxy S24", "score": 0.82}
        ][:limit]
    
    def content_based_recommendations(self, user_id, limit=10):
        """Generate recommendations based on content similarity"""
        return [
            {"product_id": 1, "name": "iPhone 15 Pro", "similarity": 0.92},
            {"product_id": 6, "name": "Apple Watch Series 9", "similarity": 0.85},
            {"product_id": 8, "name": "iPad Air", "similarity": 0.78}
        ][:limit]
    
    def hybrid_recommendations(self, user_id, limit=10):
        """Generate hybrid recommendations"""
        collaborative = self.collaborative_filtering_recommendations(user_id, limit//2)
        content_based = self.content_based_recommendations(user_id, limit//2)
        
        # Combine and deduplicate
        all_recs = collaborative + content_based
        seen = set()
        unique_recs = []
        
        for rec in all_recs:
            if rec['product_id'] not in seen:
                seen.add(rec['product_id'])
                unique_recs.append(rec)
        
        return unique_recs[:limit]
    
    def add_user_interaction(self, user_id, product_id, rating, interaction_type):
        """Record user interaction for recommendations"""
        if user_id not in self.user_interactions:
            self.user_interactions[user_id] = []
        
        self.user_interactions[user_id].append({
            'product_id': product_id,
            'rating': rating,
            'type': interaction_type,
            'timestamp': '2024-01-01T00:00:00'  # In real app, use actual timestamp
        })