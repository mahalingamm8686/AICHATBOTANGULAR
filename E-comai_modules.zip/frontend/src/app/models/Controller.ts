export enum Controller {
  User = 'user',
  Auth = 'auth',
  Product = 'product',
  Order = 'order',

  
}
