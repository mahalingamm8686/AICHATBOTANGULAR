export enum Action {
  Search = 'search',
  Recommendations = 'recommendations',
  CategoriesAll = 'categories/all'
}
