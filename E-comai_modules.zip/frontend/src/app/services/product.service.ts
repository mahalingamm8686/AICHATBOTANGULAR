import { Injectable } from '@angular/core';
import { BehaviorSubject, map, Observable, of } from 'rxjs';
import { Product } from '../models/product.model';
import nlp from 'compromise';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private productsSubject = new BehaviorSubject<Product[]>([]);

  
private aiConcepts: any[] = [
  {
    name: "Natural Language Processing (NLP)",
    definition: "Enables machines to understand, interpret, and respond to human language (text or voice).",
    examples: ["Chatbots", "Product search", "Sentiment analysis"]
  },
  {
    name: "Recommendation Systems",
    definition: "Uses data to suggest relevant products, content, or actions to users.",
    examples: ["E-commerce product suggestions", "Movie recommendations", "Content personalization"]
  },
  // add more AI concepts here
];
  public mockProducts: any[] = [
    {
      id: '1',
      name: 'Moringa Leaf Powder',
      description: 'Drumsticks are an integral part of the delicious sambhar and other South Indian delicacies. It has a unique taste and texture. You would be surprised to know moringa benefits that are highly essential for the human body. Astonishingly all its parts are edible as well.',
      price: 1250.00,
      originalPrice: 1449.99,
      images: ['../../assets/1.1.jpg'],
      category: 'Moringa',
      brand: 'Leaf Powder',
      rating: 4.6,
      reviewCount: 890,
      inStock: true,
      relatedProducts: [2, 3],
      features: ['1 lb / 454 grams', 'Organic Ingredients'],
      specifications: {
        'Availability': 'In Stock',
        'SGD Point': '1250',     
      },
    },
     {
      id: '2',
      name: 'Moringa Oil',
      description: 'Moringa oil (malunggay oil) (Ben oil) comes from the seeds of Moringa Oleifera Tree. These are extremely rich in phytonutrients and can make a great impact on your overall health. Moringa oil (malunggay oil) (Ben oil) is exceptionally famous for the numerous benefits that it offers. It is really famous in the skin and beauty care industry. In this article, we will try to give you more information on how you may put this oil to different uses and enjoy its benefits.',
      price: 1000.00,
      originalPrice: 1409.99,
      images: ['../../assets/5.jpg'],
      category: 'Moringa',
      brand: 'Leaf Powder',
      rating: 4.6,
      reviewCount: 890,
      inStock: true,
      relatedProducts: [1, 3],
      features: ['1 lb / 454 grams', 'Organic Ingredients'],
      specifications: {
        'ENHANCED CALM, FOCUS & POWERFUL ANTIOXIDANTS : Instackleaves Moringa Leaf Powder is a natural source of vitamins, minerals, and antioxidants that help support mental clarity, focus, and overall well-being.': '',
        'SGD Point': '1250',
      },
    },
      {
      id: '3',
      name: 'Moringa and Matcha super green energy',
    description:  'Moringa and Matcha super green energy 120 veg capsules',
      price: 1350.00,
      originalPrice: 1980.99,
      images: ['../../assets/3.4.jpg'],
      category: 'Moringa',
      brand: 'Leaf Powder',
      rating: 4.6,
      reviewCount: 890,
      inStock: true,
      relatedProducts: [2, 1],
      features: ['1 lb / 454 grams', 'Organic Ingredients'],
      specifications: {
        'Availability': 'In Stock',
        'SGD Point': '1250',     
      },
    },
    {
      id: '10',
      name: 'Premium Wireless Headphones',
      description: 'High-quality wireless headphones with noise cancellation and premium sound quality.',
      price: 299.99,
      originalPrice: 399.99,
      images: ['https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg'],
      category: 'Electronics',
      brand: 'AudioTech',
      rating: 4.8,
      reviewCount: 1250,
       relatedProducts: [2, 18, 19],
      inStock: true,
      features: ['Noise Cancellation', '30-hour Battery', 'Quick Charge', 'Premium Build'],
      specifications: {
        'Battery Life': '30 hours',
        'Connectivity': 'Bluetooth 5.0',
        'Weight': '250g',
        'Warranty': '2 years'
      },
    },
    {
      id: '4',
      name: 'Turmeric Ginger Supermix Classic Golden Milk',
      description: 'Turmeric golden milk is blend of natural ingredients like turmeric root powder, curcumin extract, black pepper fruit, cardamom, ginger root, cinnamon. These organic ingredients are blended together and given as turmeric golden milk power.',
      price: 299.99,
      originalPrice: 399.99,
      images: ['../../assets/4.1.jpg'],
      category: 'Turmeric',
      brand: 'Turmeric',
      rating: 4.8,
      reviewCount: 1250,
       relatedProducts: [5,4],
      inStock: true,
      features: ['8 oz / 227 grams', ''],
      specifications: {
        // 'Battery Life': '30 hours',
        // 'Connectivity': 'Bluetooth 5.0',
        // 'Weight': '250g',
        // 'Warranty': '2 years'
      },
    },
    {
      id: '5',
      name: 'Turmeric Oil',
      description: 'Organic Veda offers the finest grade of organic essential oils, with pure and organic ingredients, containing no chemicals or preservatives. This steam-distilled turmeric oil a premium, undiluted professional-grade aromatherapy oil obtained through steam-distillation of turmeric rhizomes, which are sometimes referred to as root stalks. Experience the different health benefits of turmeric in just a few drops',
      price: 299.99,
      originalPrice: 399.99,
      images: ['../../assets/5.1.jpg'],
      category: 'Turmeric',
      brand: 'Turmeric',
      rating: 4.8,
      reviewCount: 150,
       relatedProducts: [5,4],
      inStock: true,
      features: ['Turmeric oil 1.7 fl.oz / 50 ml'],
      specifications: {
        // 'Battery Life': '30 hours',
        // 'Connectivity': 'Bluetooth 5.0',
        // 'Weight': '250g',
        // 'Warranty': '2 years'
      },
    },
    {
      id: '6',
      name: 'Premium Wireless Headphones',
      description: 'High-quality wireless headphones with noise cancellation and premium sound quality.',
      price: 299.99,
      originalPrice: 399.99,
      images: ['https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg'],
      category: 'Electronics',
      brand: 'AudioTech',
      rating: 4.8,
      reviewCount: 1250,
       relatedProducts: [2, 18, 19],
      inStock: true,
      features: ['Noise Cancellation', '30-hour Battery', 'Quick Charge', 'Premium Build'],
      specifications: {
        'Battery Life': '30 hours',
        'Connectivity': 'Bluetooth 5.0',
        'Weight': '250g',
        'Warranty': '2 years'
      },
    },
    {
      id: '17',
      name: 'Smart Fitness Tracker',
      description: 'Advanced fitness tracker with heart rate monitoring and GPS tracking.',
      price: 199.99,
      originalPrice: 249.99,
      images: ['https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg'],
      category: 'Wearables',
      brand: 'FitTech',
      rating: 4.6,
      reviewCount: 890,
      inStock: true,
      relatedProducts: [22, 23],
      features: ['Heart Rate Monitor', 'GPS Tracking', 'Water Resistant', 'Sleep Tracking'],
      specifications: {
        'Battery Life': '7 days',
        'Display': 'AMOLED',
        'Water Rating': '5ATM',
        'Sensors': 'HR, GPS, Accelerometer'
      },
    },
    {
      id: '11',
      name: 'Professional Camera Lens',
      description: 'High-performance camera lens for professional photography.',
      price: 899.99,
      originalPrice: 1199.99,
      images: ['https://images.pexels.com/photos/90946/pexels-photo-90946.jpeg'],
      category: 'Photography',
      brand: 'LensMaster',
      rating: 4.9,
      reviewCount: 567,
      relatedProducts: [ 2, 1],
      inStock: true,
      features: ['Ultra-Wide Angle', 'Image Stabilization', 'Weather Sealed', 'Fast Autofocus'],
      specifications: {
        'Focal Length': '16-35mm',
        'Aperture': 'f/2.8',
        'Weight': '680g',
        'Mount': 'Universal'
      }
    },
    {
      id: '101',
      name: 'Gaming Mechanical Keyboard',
      description: 'RGB backlit mechanical keyboard designed for gaming enthusiasts.',
      price: 149.99,
      originalPrice: 199.99,
      images: ['https://images.pexels.com/photos/2115257/pexels-photo-2115257.jpeg'],
      category: 'Gaming',
      brand: 'GameTech',
      rating: 4.7,
      reviewCount: 2100,
      inStock: true,
      relatedProducts: [ 2, 1],
      features: ['RGB Backlighting', 'Mechanical Switches', 'Anti-Ghosting', 'Programmable Keys'],
      specifications: {
        'Switch Type': 'Blue Mechanical',
        'Connectivity': 'USB-C',
        'Backlighting': 'RGB',
        'Key Layout': 'Full Size'
      }
    },
    {
      id: '8',
      name: 'Vivo V60 5G',
      description: '50 MP Zeiss OIS Main Camera: OIS; f/1.88; FOV 84°; 6P lens, 50 MP Zeiss Super Telephoto Camera: AF; OIS, f/2.65, FoV 33.1°, 4P lens 10X Telephoto Stage Portrait, 8 MP ZEISS Ultra Wide-Angle camera: f2.0, FoV 120° ± 3, 5P lens | Front Camera: 50 MP ZEISS Group Selfie Camera: AF, f/2.2, FoV 92° ± 3°, 5P lens | 4K/1080P/720P Video Recording Resolution.',
      price: 89.99,
      originalPrice: 129.99,
      images: ['../../assets/vivo.jpg'],
      category: 'Smartphones',
      brand: 'Vivo',
      rating: 4.5,
      reviewCount: 1580,
      relatedProducts: [ 14, 16,15],
      inStock: true,
      features: ['360° Sound', 'Waterproof', '20-hour Battery', 'Voice Assistant'],
      specifications: {
        'Battery Life': '20 hours',
        'Water Rating': 'IPX7',
        'Connectivity': 'Bluetooth 5.0',
        'Output Power': '25W'
      }
    },
     {
      id: '12',
      name: 'large laptop backpack',
      description: 'Safari Omega spacious/large laptop backpack with Raincover, college bag, travel bag for men and women, Black, 30 Litre.',
      price: 99.00,
      originalPrice: 129.99,
      images: ['../../assets/safaribag.jpg'],
      category: 'Audio',
      brand: 'SoundWave',
      rating: 4.5,
      reviewCount: 1580,
      relatedProducts: [ 2, 1],
      inStock: true,
      features: ['360° Sound', 'Waterproof', '20-hour Battery', 'Voice Assistant'],
      specifications: {
        'Battery Life': '20 hours',
        'Water Rating': 'IPX7',
        'Connectivity': 'Bluetooth 5.0',
        'Output Power': '25W'
      }
    }, {
      id: '13',
      name: 'Portable Bluetooth Speaker',
      description: 'Compact wireless speaker with powerful sound and long battery life.',
      price: 939.00,
      originalPrice: 129.99,
      images: ['https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg'],
      category: 'Audio',
      brand: 'SoundWave',
      rating: 4.5,
      reviewCount: 1580,
      relatedProducts: [ 2, 1],
      inStock: true,
      features: ['360° Sound', 'Waterproof', '20-hour Battery', 'Voice Assistant'],
      specifications: {
        'Battery Life': '20 hours',
        'Water Rating': 'IPX7',
        'Connectivity': 'Bluetooth 5.0',
        'Output Power': '25W'
      }
    }, {
      id: '9',
      name: 'Portable Bluetooth Speaker',
      description: 'Compact wireless speaker with powerful sound and long battery life.',
      price: 9.00,
      originalPrice: 129.99,
      images: ['https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg'],
      category: 'Audio',
      brand: 'SoundWave',
      rating: 4.5,
      reviewCount: 1580,
      relatedProducts: [ 2, 1],
      inStock: true,
      features: ['360° Sound', 'Waterproof', '20-hour Battery', 'Voice Assistant'],
      specifications: {
        'Battery Life': '20 hours',
        'Water Rating': 'IPX7',
        'Connectivity': 'Bluetooth 5.0',
        'Output Power': '25W'
      }
    }, {
      id: '14',
      name: 'Boat Headphone',
      description: 'Compact wireless speaker with powerful sound and long battery life.',
      price: 79.00,
      originalPrice: 129.99,
      images: ['../../assets/boatheadphone.jpg'],
      category: 'Audio',
      brand: 'SoundWave',
      rating: 4.5,
      reviewCount: 1580,
      relatedProducts: [ 2, 1],
      inStock: true,
      features: ['360° Sound', 'Waterproof', '20-hour Battery', 'Voice Assistant'],
      specifications: {
        'Battery Life': '20 hours',
        'Water Rating': 'IPX7',
        'Connectivity': 'Bluetooth 5.0',
        'Output Power': '25W'
      }
    }, {
      id: '15',
      name: 'Back Cover',
      description: 'Compact wireless speaker with powerful sound and long battery life.',
      price: 66.00,
      originalPrice: 129.99,
      images: ['../../assets/backcover.jpg'],
      category: 'Audio',
      brand: 'SoundWave',
      rating: 4.5,
      reviewCount: 1580,
      relatedProducts: [ 2, 1],
      inStock: true,
      features: ['360° Sound', 'Waterproof', '20-hour Battery', 'Voice Assistant'],
      specifications: {
        'Battery Life': '20 hours',
        'Water Rating': 'IPX7',
        'Connectivity': 'Bluetooth 5.0',
        'Output Power': '25W'
      }
    }, {
      id: '16',
      name: 'Back cover2',
      description: 'Compact wireless speaker with powerful sound and long battery life.',
      price: 45.00,
      originalPrice: 129.99,
      images: ['../../assets/back cover 2.jpg'],
      category: 'Audio',
      brand: 'SoundWave',
      rating: 4.5,
      reviewCount: 1580,
      relatedProducts: [ 2, 1],
      inStock: true,
      features: ['360° Sound', 'Waterproof', '20-hour Battery', 'Voice Assistant'],
      specifications: {
        'Battery Life': '20 hours',
        'Water Rating': 'IPX7',
        'Connectivity': 'Bluetooth 5.0',
        'Output Power': '25W'
      }
    }, {
      id: '4',
      name: 'HP OmniBook',
      description: 'Snapdragon X Plus Processor for Performance on the Move】 Stay productive wherever you go with the Snapdragon X processor offering 8 cores, 8 threads, and 12 MB L3 cache for responsive multitasking, and up to 47 TOPS of NPU power.',
      price: 110.00,
      originalPrice: 129.99,
      images: ['../../assets/Laptop.jpg'],
      category: 'Laptops',
      brand: 'SoundWave',
      rating: 4.5,
      reviewCount: 1580,
      relatedProducts: [ 19, 18,11,20,21],
      inStock: true,
      features: ['360° Sound', 'Waterproof', '20-hour Battery', 'Voice Assistant'],
      specifications: {
        'Battery Life': '20 hours',
        'Water Rating': 'IPX7',
        'Connectivity': 'Bluetooth 5.0',
        'Output Power': '25W'
      }
    }, {
      id: '18',
      name: 'Headphone Stand ',
      description: 'Compact wireless speaker with powerful sound and long battery life.',
      price: 120.00,
      originalPrice: 129.99,
      images: ['../../assets/71maDC2XPpL._SX522_.jpg'],
      category: 'Audio',
      brand: 'SoundWave',
      rating: 4.5,
      reviewCount: 1580,
      relatedProducts: [ 2, 1],
      inStock: true,
      features: ['360° Sound', 'Waterproof', '20-hour Battery', 'Voice Assistant'],
      specifications: {
        'Battery Life': '20 hours',
        'Water Rating': 'IPX7',
        'Connectivity': 'Bluetooth 5.0',
        'Output Power': '25W'
      }
    }, {
      id: '19',
      name: 'PLIXIO Aluminum Tabletop Laptop Stand Ergonomic',
      description: 'Compact wireless speaker with powerful sound and long battery life.',
      price: 320.00,
      originalPrice: 129.99,
      images: ['../../assets/laptop stand.jpg'],
      category: 'Audio',
      brand: 'SoundWave',
      rating: 4.5,
      reviewCount: 1580,
      relatedProducts: [ 2, 1],
      inStock: true,
      features: ['360° Sound', 'Waterproof', '20-hour Battery', 'Voice Assistant'],
      specifications: {
        'Battery Life': '20 hours',
        'Water Rating': 'IPX7',
        'Connectivity': 'Bluetooth 5.0',
        'Output Power': '25W'
      }
    }, {
      id: '10',
      name: 'Portable Bluetooth Speaker',
      description: 'Compact wireless speaker with powerful sound and long battery life.',
      price: 350.00,
      originalPrice: 129.99,
      images: ['https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg'],
      category: 'Audio',
      brand: 'SoundWave',
      rating: 4.5,
      reviewCount: 1580,
      relatedProducts: [ 2, 1],
      inStock: true,
      features: ['360° Sound', 'Waterproof', '20-hour Battery', 'Voice Assistant'],
      specifications: {
        'Battery Life': '20 hours',
        'Water Rating': 'IPX7',
        'Connectivity': 'Bluetooth 5.0',
        'Output Power': '25W'
      }
    }, {
      id: '20',
      name: 'Portable Bluetooth Speaker',
      description: 'Compact wireless speaker with powerful sound and long battery life.',
      price: 3890.00,
      originalPrice: 129.99,
      images: ['../../assets/charger.jpg'],
      category: 'Audio',
      brand: 'SoundWave',
      rating: 4.5,
      reviewCount: 1580,
      relatedProducts: [ 2, 1],
      inStock: true,
      features: ['360° Sound', 'Waterproof', '20-hour Battery', 'Voice Assistant'],
      specifications: {
        'Battery Life': '20 hours',
        'Water Rating': 'IPX7',
        'Connectivity': 'Bluetooth 5.0',
        'Output Power': '25W'
      }
    }, 
    
    {
      id: '21',
      name: 'key board',
      description: 'Compact wireless speaker with powerful sound and long battery life.',
      price: 60.00,
      originalPrice: 129.99,
      images: ['../../assets/keyboard.jpg'],
      category: 'Audio',
      brand: 'SoundWave',
      rating: 4.5,
      reviewCount: 1580,
      relatedProducts: [ 2, 1],
      inStock: true,
      features: ['360° Sound', 'Waterproof', '20-hour Battery', 'Voice Assistant'],
      specifications: {
        'Battery Life': '20 hours',
        'Water Rating': 'IPX7',
        'Connectivity': 'Bluetooth 5.0',
        'Output Power': '25W'
      }
    },
     {
      id: '22',
      name: 'key board',
      description: 'Wisely Protective Case Cover Compatible with Huawei Watch Fit 4',
      price: 650.00,
      originalPrice: 129.99,
      images: ['../../assets/watch cover.jpg'],
      category: 'Audio',
      brand: 'SoundWave',
      rating: 4.5,
      reviewCount: 1580,
      relatedProducts: [ 2, 1],
      inStock: true,
      features: ['360° Sound', 'Waterproof', '20-hour Battery', 'Voice Assistant'],
      specifications: {
        'Battery Life': '20 hours',
        'Water Rating': 'IPX7',
        'Connectivity': 'Bluetooth 5.0',
        'Output Power': '25W'
      }
    },

  {
      id: '23',
      name: 'key board',
      description: 'Wisely Protective Case Cover Compatible with Huawei Watch Fit 4',
      price: 670.00,
      originalPrice: 129.99,
      images: ['../../assets/band cover.jpg'],
      category: 'Audio',
      brand: 'SoundWave',
      rating: 4.5,
      reviewCount: 1580,
      relatedProducts: [ 2, 1],
      inStock: true,
      features: ['360° Sound', 'Waterproof', '20-hour Battery', 'Voice Assistant'],
      specifications: {
        'Battery Life': '20 hours',
        'Water Rating': 'IPX7',
        'Connectivity': 'Bluetooth 5.0',
        'Output Power': '25W'
      }
    },{
    id: '23',
    name: 'Key Board',
    description: 'Wisely Protective Case Cover Compatible with Huawei Watch Fit 4',
    price: 670.0,
    originalPrice: 129.99,
    images: ['https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=400'],
    category: 'Audio',
    brand: 'SoundWave',
    rating: 4.5,
    reviewCount: 1580,
    relatedProducts: [2, 1],
    inStock: true,
    features: ['360° Sound', 'Waterproof', '20-hour Battery', 'Voice Assistant'],
    specifications: {
      'Battery Life': '20 hours',
      'Water Rating': 'IPX7',
      'Connectivity': 'Bluetooth 5.0',
      'Output Power': '25W'
    }
  },
  {
    id: '24',
    name: 'Gaming RAM 16GB DDR4',
    description: 'High-speed DDR4 RAM for gaming PCs and workstations',
    price: 4500.0,
    originalPrice: 5999.99,
    images: ['https://images.unsplash.com/photo-1619595955121-36b2c89ff66f?w=400'],
    category: 'Computer Components',
    brand: 'HyperX',
    rating: 4.8,
    reviewCount: 3200,
    relatedProducts: [23, 25],
    inStock: true,
    features: ['3200MHz Speed', 'Low Latency', 'RGB Lighting'],
    specifications: {
      'Capacity': '16GB',
      'Type': 'DDR4',
      'Speed': '3200MHz',
      'Voltage': '1.35V'
    }
  },
  {
    id: '25',
    name: 'SSD 1TB NVMe',
    description: 'Ultra-fast NVMe SSD for gaming and productivity',
    price: 7500.0,
    originalPrice: 9999.0,
    images: ['https://images.unsplash.com/photo-1618599807084-6e3c2a8a32ec?w=400'],
    category: 'Computer Components',
    brand: 'Samsung',
    rating: 4.9,
    reviewCount: 2100,
    relatedProducts: [24, 26],
    inStock: true,
    features: ['1TB Storage', '3500MB/s Read', 'Durable'],
    specifications: {
      'Capacity': '1TB',
      'Interface': 'PCIe Gen3 NVMe',
      'Form Factor': 'M.2 2280',
      'Read Speed': '3500MB/s'
    }
  },
  {
    id: '26',
    name: 'Smart Watch',
    description: 'Fitness tracker smartwatch with heart rate and sleep monitoring',
    price: 3499.0,
    originalPrice: 4999.99,
    images: ['https://images.unsplash.com/photo-1603816245453-2e1e34c46d4f?w=400'],
    category: 'Wearables',
    brand: 'FitTrack',
    rating: 4.4,
    reviewCount: 3000,
    relatedProducts: [25, 27],
    inStock: true,
    features: ['Heart Rate Monitor', 'GPS', 'Waterproof', 'Sleep Tracking'],
    specifications: {
      'Battery Life': '7 days',
      'Water Rating': '5 ATM',
      'Connectivity': 'Bluetooth 5.1',
      'Display': 'AMOLED'
    }
  },
  {
    id: '27',
    name: 'Bluetooth Speaker',
    description: 'Portable speaker with deep bass and wireless streaming',
    price: 1899.0,
    originalPrice: 2499.99,
    images: ['https://images.unsplash.com/photo-1570819739700-8141e7d8d93b?w=400'],
    category: 'Audio',
    brand: 'BoomBox',
    rating: 4.3,
    reviewCount: 1800,
    relatedProducts: [26, 28],
    inStock: true,
    features: ['Deep Bass', 'Portable', 'Wireless Streaming'],
    specifications: {
      'Battery Life': '15 hours',
      'Water Rating': 'IPX6',
      'Connectivity': 'Bluetooth 5.0',
      'Output Power': '20W'
    }
  },
  // More products auto-generated with placeholders
  ...Array.from({ length: 45 }, (_, i) => {
    const id = 28 + i;
    return {
      id: id.toString(),
      name: `Product ${id}`,
      description: `High-quality and durable product ${id}.`,
      price: +(Math.random() * 5000 + 500).toFixed(2),
      originalPrice: +(Math.random() * 7000 + 1000).toFixed(2),
      images: [`https://picsum.photos/seed/product${id}/400/400`],
      category: ['Audio', 'Wearables', 'Accessories', 'Electronics', 'Computer Components'][Math.floor(Math.random() * 5)],
      brand: ['SoundWave', 'FitTrack', 'TechGear', 'HomePlus', 'GadgetPro'][Math.floor(Math.random() * 5)],
      rating: +(Math.random() * 2 + 3).toFixed(1),
      reviewCount: Math.floor(Math.random() * 3000 + 100),
      relatedProducts: [23, 24, 25].sort(() => Math.random() - 0.5).slice(0, 2),
      inStock: Math.random() > 0.2,
      features: ['High Quality', 'Durable', 'Best Seller', 'Warranty Included'].sort(() => Math.random() - 0.5).slice(0, 3),
      specifications: {
        'Battery Life': `${Math.floor(Math.random() * 30 + 5)} hours`,
        'Water Rating': ['IPX5', 'IPX6', 'IPX7'][Math.floor(Math.random() * 3)],
        'Connectivity': ['Bluetooth 5.0', 'Bluetooth 5.1', 'Bluetooth 5.2'][Math.floor(Math.random() * 3)],
        'Output Power': `${Math.floor(Math.random() * 50 + 5)}W`
      }
    };
  })

  ];

  constructor() {
    this.productsSubject.next(this.mockProducts);
  }

  getProducts(): Observable<Product[]> {
    return this.productsSubject.asObservable();
  }

  getProduct(id: string): Observable<Product | undefined> {
    const product = this.mockProducts.find(p => p.id === id);
    return of(product);
  }

  getProductsByCategory(category: string): Observable<Product[]> {
    const filtered = this.mockProducts.filter(product =>
      product.category.toLowerCase() === category.toLowerCase()
    );
    return of(filtered);
  }

  // getRecommendedProducts(currentProductId?: string): Observable<Product[]> { debugger
  //   let recommendations = [...this.mockProducts];
  //   if (currentProductId) {
  //     recommendations = recommendations.filter(p => p.id !== currentProductId);
  //   }
  //   return of(recommendations.slice(0, 4));
  // }

 getRecommendedProducts(currentProductId?: string): Observable<Product[]> {
  let recommendations: Product[] = [];

  if (currentProductId) {
    // find the current product
    const currentProduct = this.mockProducts.find(p => p.id === currentProductId);

    if (currentProduct && currentProduct.relatedProducts?.length) {
      // map related product IDs to actual products
      recommendations = currentProduct.relatedProducts
        .map((relatedId :any)=> this.mockProducts.find(p => p.id === String(relatedId)))
        .filter((p:any): p is Product => !!p); // keep only valid products
    }
  }

  // if no relatedProducts found, fallback to generic 4 (excluding current)
  if (recommendations.length === 0) {
    recommendations = this.mockProducts
      .filter(p => p.id !== currentProductId)
      .slice(0, 4);
  }

  return of(recommendations);
}

 ask(question: string): string {
    const doc = nlp(question.toLowerCase());
    const product = this.mockProducts.find((p) =>
      question.toLowerCase().includes(p.name.toLowerCase())
    );

    if (!product) return "Sorry, I couldn't find that product.";

    const wantsPrice = question.includes('price');
    const wantsFeatures =
      question.includes('features') || question.includes('specs');
    const wantsStock =
      question.includes('stock') || question.includes('available');

    let answer = `Here's what I found about ${product.name}:`;

    if (wantsPrice) answer += ` Price: ₹${product.price}.`;
    if (wantsFeatures)
      answer += ` Features: ${product.features.join(', ')}.`;
    if (wantsStock)
      answer += ` Stock: ${product.specifications.Availability}.`;

    if (!wantsPrice && !wantsFeatures && !wantsStock)
      answer += ` ${product.description}`;

    return answer;
  }

  searchProducts(query: string): Observable<Product[]> { debugger 
    return this.getProducts().pipe(
      map((products: any) => {
        const queryLower = query.toLowerCase();
        return products.filter((p: any) => 
          p.name.toLowerCase().includes(queryLower) ||
          p.description.toLowerCase().includes(queryLower) ||
          p.category.toLowerCase().includes(queryLower) ||
          p.brand.toLowerCase().includes(queryLower) ||
          (p.features && p.features.some((f: string) => f.toLowerCase().includes(queryLower))) ||
          (p.specifications && Object.values(p.specifications).some((spec: any) => 
            spec.toLowerCase().includes(queryLower)
          ))
        );
      })
    );
  }

  getProductById(productId: string): Observable<Product> {
    const product = this.mockProducts.find((p:any) => p.id === productId);
    return of(product as Product);
  }
 filterConceptsFuzzy(query: string): any[] {
  const lowerQuery = query.toLowerCase().trim();
  if (!lowerQuery) return [];

  const queryWords = lowerQuery.split(/\s+/);

  return this.aiConcepts.filter((concept :any)=> {
    const searchableText = [
      concept.name,
      concept.definition,
      ...concept.examples
    ]
      .join(" ")
      .toLowerCase();

    return queryWords.some(word => searchableText.includes(word));
  });
}





}
