export const environment = {
  production: true,
  geminiApiKey: 'AIzaSyDyGukevGDZld2MsmcffD43hxr_jfx7lOs',
  stripePublishableKey: 'YOUR_STRIPE_PUBLISHABLE_KEY_HERE',
  apiUrl: 'http://localhost:8000/api'
};